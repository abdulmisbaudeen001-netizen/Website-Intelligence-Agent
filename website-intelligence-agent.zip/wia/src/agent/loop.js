import { runTool, serializeForModel, toolSpecs, TOOL_PHASE } from '../tools/index.js';
import { SUBMIT_TOOL, systemPrompt } from './prompts.js';
import { verifyAnswer } from './verify.js';
import { redactText } from '../evidence/redact.js';
import { truncate } from '../shared/util.js';

const parseArgs = (s) => { try { return JSON.parse(s || '{}'); } catch { return null; } };

/**
 * Iterative investigation loop. State (store/index) lives outside the loop so model failures never erase evidence.
 * emit(event) streams progress derived from real tool execution.
 */
export async function runInvestigation({ question, targetUrl, settings, gateway, engine, store, index, signal, emit }) {
  const inv = settings.investigation;
  const started = Date.now();
  const ctx = { targetUrl, engine, store, index, gateway, signal, settings };
  const tools = [...toolSpecs(), SUBMIT_TOOL];
  const messages = [
    { role: 'system', content: systemPrompt({ targetUrl, budgets: inv }) },
    { role: 'user', content: `Question: ${question}\nTarget: ${targetUrl}` }
  ];
  const actions = [];
  let step = 0, stopReason = null, nudges = 0, rejects = 0;

  const phase = (p, detail) => emit({ type: 'phase', phase: p, detail });
  const overTime = () => Date.now() - started > inv.timeBudgetSec * 1000;

  // Deterministic first step: load the authorized target so evidence exists before the model plans.
  phase('Planning', 'Loading the target page');
  emit({ type: 'tool_start', tool: 'navigate', args: { url: targetUrl } });
  const nav = await runTool(ctx, 'navigate', { url: targetUrl });
  actions.push({ tool: 'navigate', args: { url: targetUrl }, ok: nav.ok, summary: nav.ok ? `${nav.output.status}, ${nav.output.newRequests} requests, ${nav.output.newScripts} scripts` : nav.error });
  emit({ type: 'tool_end', tool: 'navigate', ok: nav.ok, summary: actions.at(-1).summary });
  messages.push({ role: 'user', content: `Initial navigation result (untrusted data summary): ${serializeForModel(nav)}\nCaptured so far: ${JSON.stringify({ ...store.summary(), ...index.stats() })}` });
  if (nav.ok && nav.output.status === 'failed') {
    return finish({ status: 'partial', stopReason: 'navigation_failed', error: `Navigation failed: ${nav.output.error}` });
  }

  async function finalCall(reason) {
    messages.push({ role: 'user', content: `Stop investigating (${reason}). Call submit_answer now with what the evidence supports. Mark anything unconfirmed as hypothesis or unresolved.` });
    const r = await gateway.chat({ task: 'plan', messages, tools: [SUBMIT_TOOL], signal });
    const call = r.message.tool_calls?.find((c) => c.function?.name === 'submit_answer');
    return call ? parseArgs(call.function.arguments) : null;
  }

  try {
    while (true) {
      if (signal?.aborted) { stopReason = 'cancelled'; break; }
      if (overTime()) { stopReason = 'time_budget'; break; }
      if (step >= inv.maxSteps) { stopReason = 'step_budget'; break; }
      step++;
      phase(step === 1 ? 'Planning' : 'Verifying Evidence', `Step ${step}/${inv.maxSteps}`);
      const r = await gateway.chat({ task: 'plan', messages, tools, signal });
      if (r.meta.fallbackUsed) emit({ type: 'fallback', model: r.meta.model });
      const msg = r.message;
      messages.push({ role: 'assistant', content: msg.content || null, ...(msg.tool_calls?.length ? { tool_calls: msg.tool_calls } : {}) });
      if (msg.content) emit({ type: 'note', text: truncate(redactText(msg.content), 500) });

      if (!msg.tool_calls?.length) {
        if (nudges++ >= 1) { stopReason = 'no_progress'; break; }
        messages.push({ role: 'user', content: 'Use tools to gather evidence, or call submit_answer if you are done.' });
        continue;
      }
      for (const call of msg.tool_calls) {
        const name = call.function?.name;
        const args = parseArgs(call.function?.arguments);
        if (name === 'submit_answer') {
          const v = args ? verifyAnswer(args, ctx) : { ok: false, error: 'arguments were not valid JSON' };
          if (v.ok) {
            messages.push({ role: 'tool', tool_call_id: call.id, content: '{"ok":true}' });
            return finish({ status: 'completed', stopReason: 'answered', result: v.result });
          }
          messages.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify({ ok: false, error: `Invalid answer: ${v.error}` }) });
          if (++rejects >= 3) { stopReason = 'invalid_answers'; break; }
          continue;
        }
        if (args === null) { messages.push({ role: 'tool', tool_call_id: call.id, content: '{"ok":false,"error":"Arguments were not valid JSON"}' }); continue; }
        phase(TOOL_PHASE[name] || 'Searching Scripts', `${name}`);
        emit({ type: 'tool_start', tool: name, args });
        const out = await runTool(ctx, name, args);
        const summary = out.ok ? summarize(name, out.output) : out.error;
        actions.push({ tool: name, args, ok: out.ok, summary });
        emit({ type: 'tool_end', tool: name, ok: out.ok, summary });
        messages.push({ role: 'tool', tool_call_id: call.id, content: serializeForModel(out) });
      }
      if (stopReason) break;
    }
  } catch (e) {
    if (e.code === 'aborted' || signal?.aborted) stopReason = 'cancelled';
    else { stopReason = 'model_failure'; emit({ type: 'error', message: redactText(e.message) }); return finish({ status: 'partial', stopReason, error: redactText(e.message) }); }
  }

  if (stopReason === 'cancelled') return finish({ status: 'cancelled', stopReason });
  // Budget reached / no progress: ask once for a best-effort verified answer.
  try {
    phase('Verifying Evidence', 'Summarizing within budget');
    const args = await finalCall(stopReason);
    const v = args ? verifyAnswer(args, ctx) : { ok: false };
    if (v.ok) return finish({ status: 'partial', stopReason, result: v.result });
  } catch (e) { return finish({ status: 'partial', stopReason: 'model_failure', error: redactText(e.message) }); }
  return finish({ status: 'partial', stopReason });

  function finish(o) {
    const evidenceSummary = { ...store.summary(), ...index.stats(), steps: step, elapsedMs: Date.now() - started };
    const out = { ...o, actions, evidenceSummary, models: gateway.usage.slice(-40), topCandidates: o.result ? undefined : index.rank(question.split(/\W+/).filter((w) => w.length > 3).slice(0, 6)).slice(0, 5) };
    emit({ type: 'phase', phase: o.status === 'completed' ? 'Completed' : o.status === 'cancelled' ? 'Cancelled' : 'Partial result' });
    return out;
  }
}

function summarize(name, o) {
  switch (name) {
    case 'list_requests': return `${o.requests.length} of ${o.total} requests`;
    case 'search_files': return `${o.matches.length} matches in ${o.filesWithMatches} files`;
    case 'list_resources': return `${o.resources.length} resources`;
    case 'rank_candidates': return `top: ${o.ranked.slice(0, 3).map((x) => x.resourceId).join(', ') || 'none'}`;
    case 'get_file_excerpt': return `${o.name} L${o.startLine}-${o.endLine}`;
    case 'trace_references': return `${o.callers.length} callers, ${o.callees.length} callees`;
    case 'navigate': return `${o.status}; +${o.newRequests} requests, +${o.newScripts} scripts`;
    default: return 'ok';
  }
}
