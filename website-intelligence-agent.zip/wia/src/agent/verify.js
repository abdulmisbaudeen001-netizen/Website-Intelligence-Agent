import { AnswerSchema } from '../shared/schemas.js';

/**
 * Deterministic verification of the model's submitted answer. Snippets are attached from the index/store
 * (never accepted from the model). Findings whose evidence cannot be resolved are downgraded.
 */
export function verifyAnswer(raw, { index, store }) {
  const parsed = AnswerSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, error: parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ') };
  const a = parsed.data;
  const notes = [];
  const findings = a.findings.map((f) => {
    let resolved = 0, bad = 0;
    const evidence = f.evidence.map((e) => {
      try {
        if (e.type === 'code') {
          const r = index.get(e.resourceId);
          const ex = index.excerpt(e.resourceId, e.startLine, Math.min(e.endLine ?? e.startLine + 14, e.startLine + 40));
          resolved++;
          return { ...e, resolved: true, name: r.name, url: r.url, view: ex.view, startLine: ex.startLine, endLine: ex.endLine, snippet: ex.text, locationNote: ex.view === 'beautified' ? 'Line numbers refer to the beautified view of a minified file; original column offsets are not preserved.' : r.kind === 'sourcemap-source' ? 'Exact location in original source from source map.' : 'Exact location in the captured file.', sourceMap: r.sourceMapStatus };
        }
        if (e.type === 'request') {
          const r = store.getRequest(e.requestId); resolved++;
          return { ...e, resolved: true, method: r.method, url: r.url, status: r.status, timestamp: r.timestamp, resourceType: r.resourceType, initiator: r.initiator, postData: r.postData, body: r.body };
        }
        const ws = store.websockets.get(e.connectionId);
        if (!ws) throw new Error('unknown ws');
        const frame = e.frameId ? store.getFrame(e.connectionId, e.frameId) : null;
        if (e.frameId && !frame) throw new Error('unknown frame');
        resolved++;
        return { ...e, resolved: true, url: ws.url, frame };
      } catch { bad++; return { ...e, resolved: false }; }
    });
    let { status, confidence } = f;
    let note = '';
    if (bad) { notes.push(`${bad} evidence reference(s) in a finding could not be resolved and were marked unresolved.`); }
    if (status === 'verified' && (resolved === 0 || bad > 0)) { status = 'hypothesis'; confidence = confidence === 'high' ? 'low' : confidence; note = resolved === 0 ? 'Downgraded: no resolvable evidence was cited.' : 'Downgraded: some cited evidence could not be resolved.'; }
    if (f.relationship === 'proven' && !evidence.some((e) => e.type === 'request' && e.initiator?.url) && !evidence.some((e) => e.type === 'ws')) { /* keep model claim but it is shown as the model's assertion */ }
    return { ...f, status, confidence, evidence, verifierNote: note };
  });
  return { ok: true, result: { ...a, findings, verifierNotes: notes } };
}
