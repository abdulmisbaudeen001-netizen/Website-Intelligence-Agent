import * as acorn from 'acorn';
import * as walk from 'acorn-walk';
import beautify from 'js-beautify';
import { SourceMapConsumer } from 'source-map-js';
import { ToolError } from '../shared/util.js';

const MAX_PARSE_BYTES = 4_000_000;

function looksMinified(text) {
  if (text.length < 2000) return false;
  const lines = text.split('\n');
  const avg = text.length / lines.length;
  return avg > 200 || lines.some((l) => l.length > 5000);
}

function detectFlags(text) {
  const flags = [];
  if (/__webpack_require__|webpackChunk/.test(text)) flags.push('webpack-bundle');
  if (/\bparcelRequire\b/.test(text)) flags.push('parcel-bundle');
  if ((text.match(/\b_0x[0-9a-f]{3,6}\b/g) || []).length > 30) flags.push('obfuscated-likely');
  if (/\beval\s*\(|new Function\s*\(/.test(text)) flags.push('dynamic-code');
  return flags;
}

/** Parse with acorn; returns {symbols, calls, imports} or {parseError}. Locations are 1-based line, 0-based column. */
function analyze(text) {
  let ast;
  const opts = { ecmaVersion: 'latest', locations: true, allowReturnOutsideFunction: true, allowAwaitOutsideFunction: true, allowHashBang: true };
  try { ast = acorn.parse(text, { ...opts, sourceType: 'module' }); }
  catch { try { ast = acorn.parse(text, { ...opts, sourceType: 'script' }); } catch (e) { return { parseError: String(e.message).slice(0, 200), symbols: [], calls: [], imports: [] }; } }

  const symbols = [];
  const symByNode = new Map();
  const add = (name, kind, node) => {
    if (!name) return;
    const s = { name, kind, startLine: node.loc.start.line, startCol: node.loc.start.column, endLine: node.loc.end.line, endCol: node.loc.end.column };
    symbols.push(s); symByNode.set(node, s);
  };
  const keyName = (k) => (!k ? null : k.type === 'Identifier' ? k.name : k.type === 'Literal' ? String(k.value) : null);
  const memberName = (m) => (m.type === 'MemberExpression' ? keyName(m.property) : m.type === 'Identifier' ? m.name : null);
  const isFn = (n) => n && (n.type === 'FunctionExpression' || n.type === 'ArrowFunctionExpression');

  walk.full(ast, (node) => {
    switch (node.type) {
      case 'FunctionDeclaration': add(node.id?.name, 'function', node); break;
      case 'ClassDeclaration': add(node.id?.name, 'class', node); break;
      case 'VariableDeclarator': if (isFn(node.init) && node.id.type === 'Identifier') add(node.id.name, 'function', node.init); break;
      case 'MethodDefinition': add(keyName(node.key), 'method', node.value); break;
      case 'Property': if (isFn(node.value)) add(keyName(node.key), 'method', node.value); break;
      case 'AssignmentExpression': if (isFn(node.right)) add(memberName(node.left), 'function', node.right); break;
    }
  });

  const calls = [];
  const imports = [];
  walk.ancestor(ast, {
    CallExpression(node, _s, anc) {
      const callee = node.callee;
      let name = callee.type === 'Identifier' ? callee.name : callee.type === 'MemberExpression' ? keyName(callee.property) : null;
      if (name === 'require' && node.arguments[0]?.type === 'Literal') imports.push({ source: String(node.arguments[0].value), line: node.loc.start.line, kind: 'require' });
      if (!name) return;
      let enclosing = null;
      for (let i = anc.length - 2; i >= 0; i--) { const s = symByNode.get(anc[i]); if (s) { enclosing = s.name; break; } }
      calls.push({ callee: name, caller: enclosing, line: node.loc.start.line, col: node.loc.start.column });
    },
    ImportDeclaration(node) { imports.push({ source: String(node.source.value), line: node.loc.start.line, kind: 'import' }); },
    ImportExpression(node) { if (node.source.type === 'Literal') imports.push({ source: String(node.source.value), line: node.loc.start.line, kind: 'dynamic-import' }); }
  });
  return { symbols, calls, imports };
}

export class CodeIndex {
  constructor({ maxResources = 60 } = {}) {
    this.maxResources = maxResources;
    this.resources = new Map(); // id -> resource
    this.seq = 0;
    this.skipped = [];
  }

  /**
   * Add a resource. kind: 'script' | 'inline' | 'sourcemap-source'.
   * Original content is preserved; analysis runs on the beautified view when minified.
   */
  addResource({ url, kind = 'script', content, contentType = '', status = 200, sourceMapUrl = null, parentId = null, requestId = null, name = null }) {
    if (typeof content !== 'string') throw new ToolError('Resource content must be a string');
    const primaryCount = [...this.resources.values()].filter((r) => r.kind !== 'sourcemap-source').length;
    if (kind !== 'sourcemap-source' && primaryCount >= this.maxResources) { this.skipped.push({ url, reason: 'maxCodeResources reached' }); return null; }
    const id = `${kind === 'inline' ? 'i' : kind === 'sourcemap-source' ? 's' : 'f'}${++this.seq}`;
    const minified = looksMinified(content);
    const view = minified ? 'beautified' : 'original';
    const text = minified ? beautify.js(content, { indent_size: 2, preserve_newlines: false, max_preserve_newlines: 1 }) : content;
    const res = {
      id, url, name: name || url, kind, contentType, status, sourceMapUrl, parentId, requestId,
      originalBytes: content.length, minified, view, text, lines: null,
      flags: detectFlags(content), parseError: null, symbols: [], calls: [], imports: [], hasSourceMap: false, sourceMapStatus: sourceMapUrl ? 'referenced' : 'none'
    };
    res.lines = text.split('\n');
    if (text.length <= MAX_PARSE_BYTES) Object.assign(res, analyze(text)); else res.parseError = 'skipped: file too large to parse';
    this.resources.set(id, res);
    return res;
  }

  /** Attach a source map to a bundle: adds each original source as its own resource with exact provenance. */
  attachSourceMap(bundleId, mapJson) {
    const bundle = this.resources.get(bundleId);
    if (!bundle) throw new ToolError(`Unknown resource ${bundleId}`);
    let map;
    try { map = typeof mapJson === 'string' ? JSON.parse(mapJson) : mapJson; new SourceMapConsumer(map); } catch (e) { bundle.sourceMapStatus = 'invalid'; return []; }
    const added = [];
    (map.sources || []).forEach((src, i) => {
      const content = map.sourcesContent?.[i];
      if (typeof content !== 'string' || /node_modules/.test(src)) return;
      const r = this.addResource({ url: bundle.url, kind: 'sourcemap-source', name: src.replace(/^webpack:\/\/[^/]*\//, ''), content, parentId: bundleId });
      if (r) added.push(r);
    });
    bundle.hasSourceMap = true;
    bundle.sourceMapStatus = added.length ? `loaded (${added.length} sources with content)` : 'loaded (no sourcesContent)';
    return added;
  }

  get(id) {
    const r = this.resources.get(id);
    if (!r) throw new ToolError(`Unknown resource id '${id}'. Use list_resources or search_files to find valid ids.`, 'not_found');
    return r;
  }

  describe(r) {
    return {
      id: r.id, name: r.name, url: r.url, kind: r.kind, status: r.status, bytes: r.originalBytes, view: r.view,
      minified: r.minified, flags: r.flags, sourceMap: r.sourceMapStatus, parseError: r.parseError,
      symbols: r.symbols.length, lines: r.lines.length, parentId: r.parentId
    };
  }

  list({ urlContains, kind } = {}) {
    return [...this.resources.values()]
      .filter((r) => (!urlContains || r.name.includes(urlContains) || r.url.includes(urlContains)) && (!kind || r.kind === kind))
      .map((r) => this.describe(r));
  }

  enclosingSymbol(r, line) {
    let best = null;
    for (const s of r.symbols) if (s.startLine <= line && s.endLine >= line && (!best || (s.endLine - s.startLine) < (best.endLine - best.startLine))) best = s;
    return best;
  }

  /** Literal or regex search. Returns bounded matches with exact line/column in the resource's analysis view. */
  search(query, { regex = false, caseSensitive = false, urlContains, kind, limit = 30, perFile = 8 } = {}) {
    if (!query) throw new ToolError('query is required', 'invalid_input');
    let re;
    try { re = regex ? new RegExp(query, caseSensitive ? 'g' : 'gi') : new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), caseSensitive ? 'g' : 'gi'); }
    catch (e) { throw new ToolError(`Invalid regex: ${e.message}`, 'invalid_input'); }
    const out = [];
    let totalFiles = 0;
    for (const r of this.resources.values()) {
      if (urlContains && !r.name.includes(urlContains) && !r.url.includes(urlContains)) continue;
      if (kind && r.kind !== kind) continue;
      let n = 0;
      for (let i = 0; i < r.lines.length && n < perFile; i++) {
        const line = r.lines[i];
        re.lastIndex = 0;
        const m = re.exec(line);
        if (!m) continue;
        const sym = this.enclosingSymbol(r, i + 1);
        const from = Math.max(0, m.index - 120);
        out.push({
          resourceId: r.id, name: r.name, view: r.view, line: i + 1, column: m.index,
          snippet: (from ? '…' : '') + line.slice(from, m.index + 200).trim(), symbol: sym?.name || null
        });
        n++;
      }
      if (n) totalFiles++;
      if (out.length >= limit) break;
    }
    return { matches: out.slice(0, limit), truncated: out.length >= limit, filesWithMatches: totalFiles };
  }

  excerpt(id, startLine, endLine, maxLines = 80) {
    const r = this.get(id);
    const s = Math.max(1, Math.floor(startLine));
    let e = Math.min(r.lines.length, Math.floor(endLine ?? s + 30));
    if (e < s) e = s;
    if (e - s + 1 > maxLines) e = s + maxLines - 1;
    return { resourceId: id, name: r.name, url: r.url, view: r.view, startLine: s, endLine: e, totalLines: r.lines.length, text: r.lines.slice(s - 1, e).join('\n').slice(0, 12000) };
  }

  getSymbol(name, { resourceId, maxLines = 80 } = {}) {
    const found = [];
    for (const r of resourceId ? [this.get(resourceId)] : this.resources.values())
      for (const s of r.symbols) if (s.name === name) found.push({ r, s });
    if (!found.length) throw new ToolError(`Symbol '${name}' not found in parsed resources`, 'not_found');
    return found.slice(0, 5).map(({ r, s }) => ({
      resourceId: r.id, name: r.name, symbol: s.name, kind: s.kind, startLine: s.startLine, endLine: s.endLine, view: r.view,
      text: r.lines.slice(s.startLine - 1, Math.min(s.endLine, s.startLine - 1 + maxLines)).join('\n').slice(0, 8000)
    }));
  }

  /** Static, name-based call graph. Heuristic: identical names in different scopes/files are not disambiguated. */
  traceReferences(name, { direction = 'both', limit = 25 } = {}) {
    const callers = [], callees = [], definitions = [], importers = [];
    for (const r of this.resources.values()) {
      for (const s of r.symbols) if (s.name === name) definitions.push({ resourceId: r.id, name: r.name, line: s.startLine, kind: s.kind });
      for (const c of r.calls) {
        if (c.callee === name && direction !== 'callees') callers.push({ resourceId: r.id, name: r.name, line: c.line, column: c.col, callerSymbol: c.caller });
        if (c.caller === name && direction !== 'callers') callees.push({ resourceId: r.id, name: r.name, line: c.line, callee: c.callee });
      }
      for (const im of r.imports) if (im.source.includes(name)) importers.push({ resourceId: r.id, name: r.name, line: im.line, source: im.source });
    }
    return {
      method: 'static name-based analysis (heuristic; same-named functions are not disambiguated; dynamic dispatch not resolved)',
      definitions: definitions.slice(0, limit), callers: callers.slice(0, limit), callees: dedupeCallees(callees).slice(0, limit), importsMatching: importers.slice(0, limit)
    };
  }

  /** Rank resources by multiple signals. Output is heuristic and labeled as such by callers. */
  rank(terms, { endpointPaths = [] } = {}) {
    const scored = [];
    for (const r of this.resources.values()) {
      let score = 0; const signals = [];
      for (const t of terms.filter(Boolean)) {
        const lc = t.toLowerCase();
        let hits = 0;
        for (const l of r.lines) if (l.toLowerCase().includes(lc)) { hits++; if (hits >= 50) break; }
        if (hits) { score += Math.min(hits, 20) * 2; signals.push(`text:${t}×${hits}`); }
        const sym = r.symbols.find((s) => s.name.toLowerCase().includes(lc));
        if (sym) { score += 6; signals.push(`symbol:${sym.name}`); }
      }
      for (const p of endpointPaths) if (p && r.text.includes(p)) { score += 12; signals.push(`endpoint:${p}`); }
      if (r.kind === 'sourcemap-source') { score += 2; signals.push('has-original-source'); }
      if (r.minified && r.kind !== 'sourcemap-source') score -= 1;
      if (/vendor|chunk-vendors|polyfill|jquery|react-dom|lodash/i.test(r.name)) { score -= 4; signals.push('likely-library'); }
      if (score > 0) scored.push({ resourceId: r.id, name: r.name, score, signals });
    }
    return scored.sort((a, b) => b.score - a.score);
  }

  stats() {
    return { resources: this.resources.size, skipped: this.skipped.length, withSourceMaps: [...this.resources.values()].filter((r) => r.hasSourceMap).length };
  }
}

function dedupeCallees(list) {
  const seen = new Set();
  return list.filter((c) => { const k = c.callee + c.resourceId; if (seen.has(k)) return false; seen.add(k); return true; });
}
