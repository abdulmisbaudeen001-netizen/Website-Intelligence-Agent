import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DEFAULT_SETTINGS, SettingsSchema } from '../shared/schemas.js';

function atomicWrite(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, data, { mode: 0o600 });
  fs.renameSync(tmp, file);
}

/**
 * Settings + OpenRouter key storage.
 * Key precedence: OPENROUTER_API_KEY env > key saved via UI. A UI-saved key is held in memory and is
 * persisted to disk ONLY if APP_SECRET is set (AES-256-GCM, scrypt-derived key). Never returned to clients.
 */
export class SettingsStore {
  constructor({ dir, env = process.env }) {
    this.dir = dir; this.env = env;
    this.file = path.join(dir, 'settings.json');
    this.keyFile = path.join(dir, 'openrouter.key.enc');
    this.settings = structuredClone(DEFAULT_SETTINGS);
    this.uiKey = null;
    this.load();
  }

  load() {
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      const merged = { models: { ...DEFAULT_SETTINGS.models, ...raw.models }, investigation: { ...DEFAULT_SETTINGS.investigation, ...raw.investigation } };
      const p = SettingsSchema.safeParse(merged);
      if (p.success) this.settings = p.data;
    } catch { /* first run or unreadable: defaults */ }
    if (this.env.APP_SECRET && fs.existsSync(this.keyFile)) {
      try { this.uiKey = this.decrypt(fs.readFileSync(this.keyFile, 'utf8')); } catch { this.uiKey = null; }
    }
  }

  get() { return this.settings; }
  update(next) {
    const p = SettingsSchema.parse(next);
    this.settings = p;
    atomicWrite(this.file, JSON.stringify(p, null, 2));
    return p;
  }

  key() { return this.env.OPENROUTER_API_KEY || this.uiKey || null; }
  keySource() { return this.env.OPENROUTER_API_KEY ? 'environment' : this.uiKey ? (this.env.APP_SECRET ? 'saved (encrypted on disk)' : 'saved (memory only; lost on restart)') : 'none'; }

  setKey(k) {
    this.uiKey = k;
    if (this.env.APP_SECRET) atomicWrite(this.keyFile, this.encrypt(k));
  }
  clearKey() { this.uiKey = null; try { fs.rmSync(this.keyFile); } catch {} }

  derive() { return crypto.scryptSync(this.env.APP_SECRET, 'wia-key-salt-v1', 32); }
  encrypt(text) {
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', this.derive(), iv);
    const enc = Buffer.concat([c.update(text, 'utf8'), c.final()]);
    return Buffer.concat([iv, c.getAuthTag(), enc]).toString('base64');
  }
  decrypt(b64) {
    const buf = Buffer.from(b64, 'base64');
    const d = crypto.createDecipheriv('aes-256-gcm', this.derive(), buf.subarray(0, 12));
    d.setAuthTag(buf.subarray(12, 28));
    return Buffer.concat([d.update(buf.subarray(28)), d.final()]).toString('utf8');
  }

  publicView() {
    return { ...this.settings, key: { configured: !!this.key(), masked: this.key() ? '••••••••••••' : '', source: this.keySource(), persistsToDisk: !!this.env.APP_SECRET && !!this.uiKey } };
  }
}
