import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { SettingsStore } from '../config/settings.js';
import { ConversationStore } from './conversations.js';
import { basicAuth, rateLimiter } from './auth.js';
import { ApiKeySchema, InvestigateSchema, SettingsSchema } from '../shared/schemas.js';
import { ModelGateway } from '../gateway/openrouter.js';
import { EvidenceStore } from '../evidence/store.js';
import { CodeIndex } from '../code/index.js';
import { BrowserEngine, browserRuntimeStatus } from '../browser/engine.js';
import { assertPublicUrl } from '../browser/urlguard.js';
import { runInvestigation } from '../agent/loop.js';
import { redactText } from '../evidence/redact.js';
import { uid } from '../shared/util.js';

const here = path.dirname(fileURLToPath(import.meta.url));

export function createApp({ dataDir, env = process.env, fetchImpl, engineFactory, runtimeStatus = browserRuntimeStatus } = {}) {
  const app = express();
  app.set('trust proxy', 1);
  const settings = new SettingsStore({ dir: dataDir, env });
  const convs = new ConversationStore(dataDir);
  const gateway = new ModelGateway({ getKey: () => settings.key(), getModels: () => settings.get().models, fetchImpl });
  const runs = new Map();
  let activeRunId = null;
  let lastValidation = null;

  app.disable('x-powered-by');
  app.use((req, res, next) => { res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY', 'Cache-Control': 'no-store' }); next(); });
  app.get('/healthz', (_q, r) => r.json({ ok: true }));
  app.use(basicAuth(env.APP_PASSWORD));
  app.use(express.json({ limit: '100kb' }));
  app.use(express.static(path.join(here, '../../public'), { maxAge: 0 }));

  const wrap = (fn) => (req, res) => Promise.resolve().then(() => fn(req, res)).catch((e) => {
    if (e?.name === 'ZodError') return res.status(400).json({ error: e.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ') });
    res.status(e.status || 500).json({ error: redactText(e.message || 'Internal error') });
  });

  // ---- settings
  app.get('/api/settings', (_q, r) => r.json(settings.publicView()));
  app.put('/api/settings', wrap((q, r) => { settings.update(SettingsSchema.parse(q.body)); r.json(settings.publicView()); }));
  app.put('/api/settings/key', wrap((q, r) => { settings.setKey(ApiKeySchema.parse(q.body).apiKey); lastValidation = null; r.json(settings.publicView()); }));
  app.delete('/api/settings/key', wrap((_q, r) => { settings.clearKey(); lastValidation = null; r.json(settings.publicView()); }));
  app.post('/api/settings/validate', wrap(async (_q, r) => { lastValidation = { ...(await gateway.validate()), at: new Date().toISOString() }; r.json(lastValidation); }));

  app.get('/api/status', (_q, r) => {
    const s = settings.get();
    const missing = [];
    if (!settings.key()) missing.push('OpenRouter API key');
    if (!s.models.primary) missing.push('Primary Reasoning Model');
    r.json({ browser: runtimeStatus(), openrouter: lastValidation, missingConfig: missing, activeRunId, security: { passwordProtected: !!env.APP_PASSWORD, privateTargetsAllowed: env.ALLOW_PRIVATE_TARGETS === '1' } });
  });

  // ---- conversations
  app.get('/api/conversations', (_q, r) => r.json(convs.list()));
  app.post('/api/conversations', wrap((_q, r) => r.status(201).json(convs.create())));
  app.get('/api/conversations/:id', wrap((q, r) => { const c = convs.get(q.params.id); c ? r.json(c) : r.status(404).json({ error: 'Not found' }); }));
  app.patch('/api/conversations/:id', wrap((q, r) => { const c = convs.rename(q.params.id, String(q.body?.title || '').trim() || 'Untitled'); c ? r.json(c) : r.status(404).json({ error: 'Not found' }); }));
  app.delete('/api/conversations/:id', wrap((q, r) => r.json({ deleted: convs.remove(q.params.id) })));
  app.delete('/api/data', wrap((q, r) => {
    if (q.query.confirm !== 'yes') return r.status(400).json({ error: 'Confirmation required (?confirm=yes)' });
    convs.clear();
    fs.rmSync(path.join(dataDir, 'artifacts'), { recursive: true, force: true });
    r.json({ cleared: true });
  }));

  // ---- investigations
  const limiter = rateLimiter({ windowMs: 3600_000, max: Number(env.INVESTIGATIONS_PER_HOUR || 20) });
  app.post('/api/conversations/:id/investigate', limiter, wrap(async (q, r) => {
    const conv = convs.get(q.params.id);
    if (!conv) return r.status(404).json({ error: 'Conversation not found' });
    const body = InvestigateSchema.parse(q.body);
    if (activeRunId) return r.status(409).json({ error: 'Another investigation is running. Wait for it or stop it first.' });
    const s = settings.get();
    if (!settings.key() || !s.models.primary) return r.status(400).json({ error: 'Setup incomplete: add your OpenRouter API key and a Primary Reasoning Model in Settings.', code: 'not_configured' });
    const br = runtimeStatus();
    if (!br.ok) return r.status(503).json({ error: `Browser runtime unavailable: ${br.detail}`, code: 'browser_unavailable' });
    try { await assertPublicUrl(body.targetUrl); } catch (e) { return r.status(400).json({ error: `Target rejected: ${e.message}` }); }

    const run = { id: uid('run_'), convId: conv.id, events: [], listeners: new Set(), abort: new AbortController(), done: false };
    runs.set(run.id, run); activeRunId = run.id;
    convs.append(conv.id, { role: 'user', content: body.question, targetUrl: body.targetUrl });
    if (conv.messages.length === 1) convs.rename(conv.id, body.question.slice(0, 60));
    execute(run, body, s, conv.id);
    r.status(202).json({ runId: run.id });
  }));

  const emit = (run) => (ev) => { const e = { ...ev, ts: Date.now(), seq: run.events.length }; run.events.push(e); for (const l of run.listeners) l(e); };

  async function execute(run, body, s, convId) {
    const em = emit(run);
    const store = new EvidenceStore({ maxRequests: s.investigation.maxRequests, payloadLimit: s.investigation.payloadLimit });
    const index = new CodeIndex({ maxResources: s.investigation.maxCodeResources });
    const engine = (engineFactory || ((o) => new BrowserEngine(o)))({ store, codeIndex: index, settings: s.investigation, onEvent: em });
    const timer = setTimeout(() => run.abort.abort(), (s.investigation.timeBudgetSec + 60) * 1000);
    let out;
    try {
      em({ type: 'phase', phase: 'Planning', detail: 'Starting isolated browser' });
      await engine.start();
      out = await runInvestigation({ question: body.question, targetUrl: body.targetUrl, settings: s, gateway, engine, store, index, signal: run.abort.signal, emit: em });
    } catch (e) {
      out = { status: 'error', stopReason: 'error', error: redactText(e.message), evidenceSummary: store.summary() };
      em({ type: 'error', message: out.error });
    } finally {
      clearTimeout(timer);
      await engine.close?.();
    }
    if (s.investigation.retainArtifacts) {
      try {
        const d = path.join(dataDir, 'artifacts'); fs.mkdirSync(d, { recursive: true });
        fs.writeFileSync(path.join(d, `${run.id}.json`), JSON.stringify({ requests: [...store.requests.values()], websockets: [...store.websockets.values()], resources: index.list() }), { mode: 0o600 });
      } catch {}
    }
    convs.append(convId, { role: 'assistant', runId: run.id, targetUrl: body.targetUrl, ...out });
    run.done = true; activeRunId = null;
    em({ type: 'done', status: out.status });
    for (const l of run.listeners) l(null);
    setTimeout(() => runs.delete(run.id), 600_000).unref?.();
  }

  app.get('/api/runs/:id/events', (q, r) => {
    const run = runs.get(q.params.id);
    if (!run) return r.status(404).json({ error: 'Run not found' });
    r.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    r.flushHeaders?.();
    const send = (e) => { if (e === null) { r.end(); return; } r.write(`data: ${JSON.stringify(e)}\n\n`); };
    run.events.forEach(send);
    if (run.done) return r.end();
    run.listeners.add(send);
    q.on('close', () => run.listeners.delete(send));
  });
  app.post('/api/runs/:id/cancel', (q, r) => { const run = runs.get(q.params.id); if (!run || run.done) return r.status(404).json({ error: 'No active run' }); run.abort.abort(); r.json({ cancelling: true }); });

  app.use('/api', (_q, r) => r.status(404).json({ error: 'Not found' }));
  return app;
}
