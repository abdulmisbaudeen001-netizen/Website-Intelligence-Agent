import crypto from 'node:crypto';

const eq = (a, b) => { const x = crypto.createHash('sha256').update(a).digest(), y = crypto.createHash('sha256').update(b).digest(); return crypto.timingSafeEqual(x, y); };

/** HTTP Basic auth gate (any username). Required in production because the app drives a browser and spends an API key. */
export function basicAuth(password) {
  return (req, res, next) => {
    if (!password || req.path === '/healthz') return next();
    const h = req.headers.authorization || '';
    if (h.startsWith('Basic ')) {
      const [, ...rest] = Buffer.from(h.slice(6), 'base64').toString('utf8').split(':');
      if (eq(rest.join(':'), password)) return next();
    }
    res.set('WWW-Authenticate', 'Basic realm="Website Intelligence Agent", charset="UTF-8"').status(401).send('Authentication required');
  };
}

export function rateLimiter({ windowMs, max }) {
  const hits = new Map();
  return (req, res, next) => {
    const k = req.ip, now = Date.now();
    const arr = (hits.get(k) || []).filter((t) => now - t < windowMs);
    if (arr.length >= max) return res.status(429).json({ error: `Rate limit: max ${max} investigations per ${Math.round(windowMs / 60000)} minutes.` });
    arr.push(now); hits.set(k, arr); next();
  };
}
