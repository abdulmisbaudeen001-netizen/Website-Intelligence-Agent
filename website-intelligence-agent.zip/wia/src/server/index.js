import path from 'node:path';
import { createApp } from './app.js';

const env = process.env;
if (env.NODE_ENV === 'production' && !env.APP_PASSWORD) {
  console.error('Refusing to start: APP_PASSWORD must be set in production (the app controls a browser and uses your API key).');
  process.exit(1);
}
const dataDir = path.resolve(env.DATA_DIR || './data');
const app = createApp({ dataDir });
const port = Number(env.PORT || 3000);
app.listen(port, '0.0.0.0', () => console.log(`Website Intelligence Agent listening on :${port} (data: ${dataDir})`));
