import fs from 'node:fs';
import path from 'node:path';
import { uid, nowIso } from '../shared/util.js';

export class ConversationStore {
  constructor(dir) {
    this.file = path.join(dir, 'conversations.json');
    this.dir = dir; this.items = new Map();
    try { for (const c of JSON.parse(fs.readFileSync(this.file, 'utf8'))) this.items.set(c.id, c); } catch {}
  }
  save() {
    fs.mkdirSync(this.dir, { recursive: true });
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify([...this.items.values()]), { mode: 0o600 });
    fs.renameSync(tmp, this.file);
  }
  list() { return [...this.items.values()].map(({ id, title, createdAt, updatedAt }) => ({ id, title, createdAt, updatedAt })).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)); }
  create(title = 'New investigation') { const c = { id: uid('c_'), title, createdAt: nowIso(), updatedAt: nowIso(), messages: [] }; this.items.set(c.id, c); this.save(); return c; }
  get(id) { return this.items.get(id) || null; }
  rename(id, title) { const c = this.get(id); if (!c) return null; c.title = String(title).slice(0, 120); c.updatedAt = nowIso(); this.save(); return c; }
  remove(id) { const ok = this.items.delete(id); if (ok) this.save(); return ok; }
  append(id, msg) { const c = this.get(id); if (!c) return null; c.messages.push({ ...msg, at: nowIso() }); c.updatedAt = nowIso(); this.save(); return c; }
  clear() { this.items.clear(); this.save(); }
}
