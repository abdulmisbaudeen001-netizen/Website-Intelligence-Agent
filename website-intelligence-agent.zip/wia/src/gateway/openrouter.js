import { sleep, truncate } from '../shared/util.js';

const BASE = 'https://openrouter.ai/api/v1';
export class GatewayError extends Error {
  constructor(message, { retryable = false, status = null, code = 'gateway_error' } = {}) { super(message); this.retryable = retryable; this.status = status; this.code = code; }
}

/** OpenRouter gateway with three configurable slots and bounded retry/fallback. Keeps provider specifics out of the agent. */
export class ModelGateway {
  constructor({ getKey, getModels, fetchImpl = fetch, timeoutMs = 90000, maxAttemptsPerModel = 2, backoffMs = 800, onEvent = () => {} }) {
    Object.assign(this, { getKey, getModels, fetchImpl, timeoutMs, maxAttemptsPerModel, backoffMs, onEvent });
    this.capCache = null; this.usage = []; this.noTools = new Set();
  }

  scrub(s) { const k = this.getKey(); let out = String(s ?? ''); if (k) out = out.split(k).join('[KEY]'); return out.replace(/sk-or-[A-Za-z0-9_-]+/g, '[KEY]'); }

  async rawFetch(path, init, signal) {
    const key = this.getKey();
    if (!key) throw new GatewayError('OpenRouter API key is not configured. Add it in Settings.', { code: 'no_key' });
    if (signal?.aborted) throw new GatewayError('Cancelled', { code: 'aborted' });
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(new Error('timeout')), this.timeoutMs);
    signal?.addEventListener('abort', () => ctrl.abort(new Error('aborted')), { once: true });
    try {
      return await this.fetchImpl(BASE + path, { ...init, signal: ctrl.signal, headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', 'X-Title': 'Website Intelligence Agent', ...(init?.headers || {}) } });
    } catch (e) {
      if (signal?.aborted) throw new GatewayError('Cancelled', { code: 'aborted' });
      throw new GatewayError(ctrl.signal.aborted ? 'Request timed out' : `Network error: ${this.scrub(e.message)}`, { retryable: true, code: ctrl.signal.aborted ? 'timeout' : 'network' });
    } finally { clearTimeout(t); }
  }

  /** Validate the key and each configured model ID against OpenRouter's model list. */
  async validate() {
    const result = { key: { ok: false, message: '' }, models: {} };
    try {
      const r = await this.rawFetch('/auth/key', { method: 'GET' });
      result.key = r.ok ? { ok: true, message: 'API key accepted' } : { ok: false, message: r.status === 401 ? 'API key rejected (401)' : `Key check failed (HTTP ${r.status})` };
    } catch (e) { result.key = { ok: false, message: this.scrub(e.message) }; return result; }
    const caps = await this.loadCaps(true).catch(() => null);
    const models = this.getModels();
    for (const slot of ['primary', 'code', 'fallback']) {
      const id = models[slot];
      if (!id) { result.models[slot] = { status: 'unconfigured', message: 'No model ID set' }; continue; }
      if (!caps) { result.models[slot] = { status: 'unknown', message: 'Could not fetch the model list to verify' }; continue; }
      const c = caps.get(id);
      result.models[slot] = !c ? { status: 'invalid', message: 'Model ID not found on OpenRouter' }
        : { status: 'ok', message: c.tools ? 'Model found; tool calling supported' : 'Model found; tool calling NOT advertised', tools: c.tools, context: c.context };
    }
    return result;
  }

  async loadCaps(force = false) {
    if (this.capCache && !force && Date.now() - this.capCache.t < 600000) return this.capCache.map;
    const r = await this.rawFetch('/models', { method: 'GET' });
    if (!r.ok) throw new GatewayError(`Model list failed (HTTP ${r.status})`);
    const j = await r.json();
    const map = new Map((j.data || []).map((m) => [m.id, { tools: (m.supported_parameters || []).includes('tools'), context: m.context_length }]));
    this.capCache = { t: Date.now(), map };
    return map;
  }

  slotsFor(task) {
    const m = this.getModels();
    const order = task === 'code' ? [['code', m.code || m.primary], ['fallback', m.fallback]] : [['primary', m.primary], ['fallback', m.fallback]];
    const seen = new Set();
    return order.filter(([, id]) => id && !seen.has(id) && seen.add(id)).map(([slot, id]) => ({ slot, id }));
  }

  /**
   * chat({task:'plan'|'code', messages, tools}) -> {message, meta}
   * Tries slot models in order; retries retryable failures with bounded attempts; reports fallback use.
   */
  async chat({ task = 'plan', messages, tools, signal, temperature = 0.1, max_tokens = 3000 }) {
    const slots = this.slotsFor(task);
    if (!slots.length) throw new GatewayError('No model configured. Set at least the Primary Reasoning Model in Settings.', { code: 'no_model' });
    let caps = null;
    if (tools) caps = await this.loadCaps().catch(() => null);
    const failures = [];
    for (let si = 0; si < slots.length; si++) {
      const { slot, id } = slots[si];
      if (tools && (this.noTools.has(id) || (caps && caps.get(id) && !caps.get(id).tools))) { failures.push(`${slot} (${id}): tool calling unsupported`); continue; }
      for (let attempt = 1; attempt <= this.maxAttemptsPerModel; attempt++) {
        const t0 = Date.now();
        try {
          const body = { model: id, messages, temperature, max_tokens, ...(tools ? { tools, tool_choice: 'auto' } : {}) };
          const r = await this.rawFetch('/chat/completions', { method: 'POST', body: JSON.stringify(body) }, signal);
          const text = await r.text();
          if (!r.ok) {
            const msg = this.scrub(truncate(text, 300));
            if (r.status === 400 && /tool/i.test(msg)) { this.noTools.add(id); throw new GatewayError(`tools unsupported: ${msg}`, { status: 400, code: 'tools_unsupported' }); }
            throw new GatewayError(`HTTP ${r.status}: ${msg}`, { status: r.status, retryable: r.status === 429 || r.status >= 500 || r.status === 408, code: 'http' });
          }
          let j; try { j = JSON.parse(text); } catch { throw new GatewayError('Malformed JSON from provider', { retryable: true, code: 'malformed' }); }
          if (j.error) throw new GatewayError(this.scrub(truncate(JSON.stringify(j.error), 300)), { retryable: true, code: 'provider_error' });
          const msg = j.choices?.[0]?.message;
          if (!msg) throw new GatewayError('Empty response from provider', { retryable: true, code: 'malformed' });
          const meta = { model: id, slot, task, latencyMs: Date.now() - t0, usage: j.usage || null, fallbackUsed: si > 0 || slot === 'fallback', attempts: attempt };
          this.usage.push(meta);
          if (meta.fallbackUsed) this.onEvent({ type: 'fallback', model: id, reason: failures.join(' | ') || 'primary unavailable' });
          return { message: msg, meta };
        } catch (e) {
          if (!(e instanceof GatewayError)) throw e;
          if (e.code === 'aborted' || e.code === 'no_key') throw e;
          failures.push(`${slot} (${id}) attempt ${attempt}: ${e.message}`);
          if (!e.retryable || attempt === this.maxAttemptsPerModel) break;
          await sleep(this.backoffMs * attempt, signal).catch(() => { throw new GatewayError('Cancelled', { code: 'aborted' }); });
        }
      }
    }
    throw new GatewayError(`All configured models failed. ${failures.slice(-4).join(' | ')}`, { code: 'all_failed' });
  }
}
