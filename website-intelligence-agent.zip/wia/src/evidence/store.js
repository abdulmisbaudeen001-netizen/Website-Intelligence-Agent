import { redactHeaders, redactUrl, redactText } from './redact.js';
import { truncate, ToolError } from '../shared/util.js';

/** Per-investigation structured evidence store (requests, WebSockets). Bounded; payloads redacted and truncated on write. */
export class EvidenceStore {
  constructor({ maxRequests = 500, payloadLimit = 4000 } = {}) {
    this.maxRequests = maxRequests;
    this.payloadLimit = payloadLimit;
    this.requests = new Map();
    this.websockets = new Map();
    this.reqSeq = 0; this.wsSeq = 0;
    this.droppedRequests = 0;
    this.startedAt = Date.now();
  }

  addRequest({ method, url, resourceType, headers, postData, initiatorUrl }) {
    if (this.requests.size >= this.maxRequests) { this.droppedRequests++; return null; }
    const id = `r${++this.reqSeq}`;
    const rec = {
      id, method, url: redactUrl(url), resourceType, t: Date.now() - this.startedAt, timestamp: new Date().toISOString(),
      requestHeaders: redactHeaders(headers), postData: postData ? truncate(redactText(postData), this.payloadLimit) : null,
      postDataBytes: postData ? postData.length : 0,
      status: null, statusText: null, responseHeaders: null, contentType: null, body: null, bodyBytes: null,
      durationMs: null, failure: null, initiator: initiatorUrl ? { url: redactUrl(initiatorUrl) } : null
    };
    this.requests.set(id, rec);
    return rec;
  }

  completeRequest(rec, { status, statusText, headers, body, bodyBytes, durationMs }) {
    rec.status = status; rec.statusText = statusText;
    rec.responseHeaders = redactHeaders(headers);
    rec.contentType = rec.responseHeaders['content-type'] || null;
    if (body != null) rec.body = truncate(redactText(body), this.payloadLimit);
    rec.bodyBytes = bodyBytes ?? null;
    rec.durationMs = durationMs;
  }

  listRequests({ urlContains, method, resourceType, status, keyword, limit = 40, sinceMs, untilMs } = {}) {
    const kw = keyword?.toLowerCase();
    const out = [];
    for (const r of this.requests.values()) {
      if (urlContains && !r.url.includes(urlContains)) continue;
      if (method && r.method !== method.toUpperCase()) continue;
      if (resourceType && r.resourceType !== resourceType) continue;
      if (status != null && r.status !== status) continue;
      if (sinceMs != null && r.t < sinceMs) continue;
      if (untilMs != null && r.t > untilMs) continue;
      if (kw && !(r.url.toLowerCase().includes(kw) || (r.postData || '').toLowerCase().includes(kw) || (r.body || '').toLowerCase().includes(kw))) continue;
      out.push({ id: r.id, method: r.method, url: truncate(r.url, 200), resourceType: r.resourceType, status: r.status, tMs: r.t, durationMs: r.durationMs, hasBody: r.postData != null });
      if (out.length >= limit) break;
    }
    return { requests: out, total: this.requests.size, dropped: this.droppedRequests };
  }

  getRequest(id) {
    const r = this.requests.get(id);
    if (!r) throw new ToolError(`Unknown request id '${id}'. Use list_requests.`, 'not_found');
    return r;
  }

  addWebSocket(url) {
    const id = `w${++this.wsSeq}`;
    const ws = { id, url: redactUrl(url), openedAt: new Date().toISOString(), t: Date.now() - this.startedAt, closedAt: null, error: null, frames: [], sent: 0, received: 0, droppedFrames: 0 };
    this.websockets.set(id, ws);
    return ws;
  }

  addFrame(ws, direction, payload) {
    if (ws.frames.length >= 400) { ws.droppedFrames++; return; }
    const isBin = typeof payload !== 'string';
    const text = isBin ? `[binary ${payload?.length ?? 0} bytes] ${Buffer.from(payload || []).subarray(0, 64).toString('hex')}` : payload;
    const id = `${ws.id}:f${ws.frames.length + 1}`;
    ws.frames.push({ id, direction, t: Date.now() - this.startedAt, timestamp: new Date().toISOString(), binary: isBin, bytes: payload?.length ?? 0, payload: truncate(redactText(text), this.payloadLimit) });
    direction === 'sent' ? ws.sent++ : ws.received++;
  }

  listWebSockets({ urlContains } = {}) {
    return [...this.websockets.values()].filter((w) => !urlContains || w.url.includes(urlContains)).map((w) => ({
      id: w.id, url: w.url, openedAt: w.openedAt, closedAt: w.closedAt, error: w.error, framesSent: w.sent, framesReceived: w.received, droppedFrames: w.droppedFrames
    }));
  }

  getFrames(connectionId, { limit = 20, direction, contains, offset = 0 } = {}) {
    const ws = this.websockets.get(connectionId);
    if (!ws) throw new ToolError(`Unknown WebSocket connection '${connectionId}'. Use list_websockets.`, 'not_found');
    const c = contains?.toLowerCase();
    const frames = ws.frames.filter((f) => (!direction || f.direction === direction) && (!c || f.payload.toLowerCase().includes(c)));
    return { connectionId, url: ws.url, totalMatching: frames.length, frames: frames.slice(offset, offset + limit) };
  }

  getFrame(connectionId, frameId) {
    const ws = this.websockets.get(connectionId);
    return ws?.frames.find((f) => f.id === frameId) || null;
  }

  summary() {
    return { requests: this.requests.size, websockets: this.websockets.size, frames: [...this.websockets.values()].reduce((a, w) => a + w.frames.length, 0), droppedRequests: this.droppedRequests };
  }
}
