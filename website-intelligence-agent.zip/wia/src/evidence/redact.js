// Redaction applied before anything is stored for display or sent to an LLM.
const SENSITIVE_HEADER = /^(authorization|proxy-authorization|cookie|set-cookie|x-api-key|x-auth-token|x-csrf-token|x-xsrf-token|x-amz-security-token)$/i;
const SENSITIVE_KEY = /(pass(word|wd)?|secret|token|api[_-]?key|apikey|authorization|session(id)?|cookie|jwt|bearer|credential|private[_-]?key|otp)/i;
const R = '[REDACTED]';

export function redactHeaders(headers = {}) {
  const out = {};
  for (const [k, v] of Object.entries(headers)) out[k.toLowerCase()] = SENSITIVE_HEADER.test(k) ? R : String(v).slice(0, 300);
  return out;
}

export function redactUrl(url) {
  try {
    const u = new URL(url);
    if (u.username || u.password) { u.username = ''; u.password = ''; }
    for (const k of [...u.searchParams.keys()]) if (SENSITIVE_KEY.test(k)) u.searchParams.set(k, R);
    return u.toString();
  } catch { return String(url).slice(0, 500); }
}

const PATTERNS = [
  [/\bBearer\s+[A-Za-z0-9._~+\/=-]{8,}/gi, 'Bearer ' + R],
  [/\bsk-[A-Za-z0-9_-]{16,}/g, R],
  [/\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{4,}/g, R],
  [/\b(AKIA|ASIA)[A-Z0-9]{16}\b/g, R],
  [/("?(?:[A-Za-z0-9_.-]*(?:pass(?:word|wd)?|secret|token|api[_-]?key|apikey|authorization|session(?:id)?|cookie|jwt|credential)[A-Za-z0-9_.-]*)"?\s*[:=]\s*)("[^"]*"|'[^']*'|[^\s,&;}"']+)/gi, (m, p1) => `${p1}"${R}"`]
];

export function redactText(s) {
  if (s == null) return s;
  let out = String(s);
  for (const [re, rep] of PATTERNS) out = out.replace(re, rep);
  return out;
}

export function redactDeep(v, depth = 0) {
  if (depth > 6) return '[depth-limit]';
  if (typeof v === 'string') return redactText(v);
  if (Array.isArray(v)) return v.slice(0, 200).map((x) => redactDeep(x, depth + 1));
  if (v && typeof v === 'object') {
    const o = {};
    for (const [k, x] of Object.entries(v)) o[k] = SENSITIVE_KEY.test(k) ? R : redactDeep(x, depth + 1);
    return o;
  }
  return v;
}
