export const sleep = (ms, signal) =>
  new Promise((res, rej) => {
    const t = setTimeout(res, ms);
    signal?.addEventListener('abort', () => { clearTimeout(t); rej(new Error('aborted')); }, { once: true });
  });

export const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
export const nowIso = () => new Date().toISOString();
export const uid = (p = '') => p + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

export function truncate(s, max) {
  if (s == null) return s;
  s = String(s);
  return s.length <= max ? s : s.slice(0, max) + `…[truncated ${s.length - max} chars]`;
}

export class ToolError extends Error {
  constructor(message, code = 'tool_error') { super(message); this.code = code; }
}
