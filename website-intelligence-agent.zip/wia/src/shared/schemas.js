import { z } from 'zod';

export const DEFAULT_SETTINGS = {
  models: { primary: '', code: '', fallback: '' },
  investigation: {
    maxRequests: 500,
    maxCodeResources: 60,
    maxSteps: 25,
    timeBudgetSec: 240,
    payloadLimit: 4000,
    inspectSourceMaps: true,
    retainArtifacts: false
  }
};

const modelId = z.string().trim().max(200).regex(/^[A-Za-z0-9._:\-\/~]*$/, 'Invalid model ID characters');

export const SettingsSchema = z.object({
  models: z.object({ primary: modelId, code: modelId, fallback: modelId }),
  investigation: z.object({
    maxRequests: z.number().int().min(20).max(5000),
    maxCodeResources: z.number().int().min(1).max(300),
    maxSteps: z.number().int().min(1).max(60),
    timeBudgetSec: z.number().int().min(15).max(900),
    payloadLimit: z.number().int().min(200).max(20000),
    inspectSourceMaps: z.boolean(),
    retainArtifacts: z.boolean()
  })
});

export const ApiKeySchema = z.object({ apiKey: z.string().trim().min(10).max(300) });

export const InvestigateSchema = z.object({
  question: z.string().trim().min(5).max(2000),
  targetUrl: z.string().trim().url().max(2000),
  authorized: z.literal(true, { errorMap: () => ({ message: 'You must confirm you are authorized to test this website.' }) })
});

// Final answer submitted by the model. Snippets are NOT accepted from the model; the verifier fills them from the index.
const EvidenceRef = z.discriminatedUnion('type', [
  z.object({ type: z.literal('code'), resourceId: z.string(), startLine: z.number().int().min(1), endLine: z.number().int().min(1).optional(), symbol: z.string().optional() }),
  z.object({ type: z.literal('request'), requestId: z.string() }),
  z.object({ type: z.literal('ws'), connectionId: z.string(), frameId: z.string().optional() })
]);

export const AnswerSchema = z.object({
  answer: z.string().min(1).max(4000),
  findings: z.array(z.object({
    claim: z.string().min(1).max(1500),
    status: z.enum(['verified', 'hypothesis', 'unresolved']),
    confidence: z.enum(['high', 'medium', 'low']),
    confidenceReason: z.string().max(600).optional().default(''),
    relationship: z.enum(['proven', 'inferred', 'none']).optional().default('none'),
    relationshipNote: z.string().max(800).optional().default(''),
    evidence: z.array(EvidenceRef).max(12).default([])
  })).max(20).default([]),
  limitations: z.array(z.string().max(500)).max(15).default([]),
  unresolved: z.array(z.string().max(500)).max(15).default([]),
  nextSteps: z.array(z.string().max(500)).max(10).default([])
});
