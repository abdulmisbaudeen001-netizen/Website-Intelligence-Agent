import dns from 'node:dns/promises';
import net from 'node:net';
import { ToolError } from '../shared/util.js';

function v4Private(ip) {
  const p = ip.split('.').map(Number);
  const [a, b] = p;
  return a === 0 || a === 10 || a === 127 || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 192 && b === 0 && p[2] === 0) || a >= 224;
}
export function isPrivateIp(ip) {
  if (net.isIPv4(ip)) return v4Private(ip);
  if (net.isIPv6(ip)) {
    const l = ip.toLowerCase();
    const mapped = l.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return v4Private(mapped[1]);
    return l === '::1' || l === '::' || l.startsWith('fc') || l.startsWith('fd') || /^fe[89ab]/.test(l);
  }
  return true;
}

const cache = new Map();
/** Throws ToolError unless URL is http(s) and resolves only to public addresses. */
export async function assertPublicUrl(raw, { allowPrivate = process.env.ALLOW_PRIVATE_TARGETS === '1' } = {}) {
  let u;
  try { u = new URL(raw); } catch { throw new ToolError('Invalid URL', 'invalid_url'); }
  if (!['http:', 'https:'].includes(u.protocol)) throw new ToolError(`Blocked scheme: ${u.protocol}`, 'blocked_scheme');
  if (allowPrivate) return u;
  const host = u.hostname.replace(/^\[|\]$/g, '');
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.internal') || host.endsWith('.local')) throw new ToolError('Blocked host (local network)', 'blocked_host');
  const c = cache.get(host);
  if (c && Date.now() - c.t < 60000) { if (c.bad) throw new ToolError('Blocked host (resolves to a non-public address)', 'blocked_host'); return u; }
  let addrs;
  if (net.isIP(host)) addrs = [{ address: host }];
  else {
    try { addrs = await dns.lookup(host, { all: true }); } catch { throw new ToolError(`DNS resolution failed for ${host}`, 'dns_failed'); }
  }
  const bad = addrs.some((a) => isPrivateIp(a.address));
  cache.set(host, { t: Date.now(), bad });
  if (bad) throw new ToolError('Blocked host (resolves to a non-public address)', 'blocked_host');
  return u;
}
