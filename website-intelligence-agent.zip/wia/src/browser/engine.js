import { chromium } from 'playwright-core';
import fs from 'node:fs';
import { assertPublicUrl } from './urlguard.js';
import { ToolError, truncate } from '../shared/util.js';

const MAX_SCRIPT_BYTES = 3_000_000;
const MAX_MAP_BYTES = 8_000_000;

export function browserRuntimeStatus() {
  const p = process.env.CHROMIUM_PATH;
  if (p) return { ok: fs.existsSync(p), detail: fs.existsSync(p) ? `Using CHROMIUM_PATH` : `CHROMIUM_PATH not found: ${p}` };
  try {
    const exe = chromium.executablePath();
    return fs.existsSync(exe) ? { ok: true, detail: 'Playwright Chromium installed' } : { ok: false, detail: 'Chromium is not installed. Run: npx playwright-core install --with-deps chromium' };
  } catch (e) { return { ok: false, detail: String(e.message).slice(0, 200) }; }
}

/**
 * One isolated, throwaway browser context per investigation. Playwright is the only browser driver.
 * CDP is used (best-effort) to obtain request initiators, which link network requests to the JS that issued them.
 */
export class BrowserEngine {
  constructor({ store, codeIndex, settings, onEvent = () => {} }) {
    this.store = store; this.index = codeIndex; this.settings = settings; this.onEvent = onEvent;
    this.browser = null; this.context = null; this.page = null; this.cdp = null;
    this.known = new Set(); this.pending = new Set(); this.initiators = new Map();
    this.disconnected = false;
  }

  async start() {
    const args = ['--disable-dev-shm-usage'];
    if (process.env.CHROMIUM_NO_SANDBOX === '1') args.push('--no-sandbox');
    this.browser = await chromium.launch({ headless: true, args, executablePath: process.env.CHROMIUM_PATH || undefined });
    this.browser.on('disconnected', () => { this.disconnected = true; });
    this.context = await this.browser.newContext({ serviceWorkers: 'block', acceptDownloads: false, ignoreHTTPSErrors: false, viewport: { width: 1280, height: 800 } });
    // Every request (including subresources and redirects) must pass the SSRF guard.
    await this.context.route('**/*', async (route) => {
      try { await assertPublicUrl(route.request().url()); await route.continue(); }
      catch { await route.abort('blockedbyclient').catch(() => {}); }
    });
    this.page = await this.context.newPage();
    this.wire();
  }

  wire() {
    const page = this.page, store = this.store;
    const recs = new Map();
    page.on('request', (req) => {
      const rec = store.addRequest({ method: req.method(), url: req.url(), resourceType: req.resourceType(), headers: req.headers(), postData: req.postData() });
      if (rec) { recs.set(req, { rec, start: Date.now() }); this.onEvent({ type: 'request', id: rec.id, url: rec.url }); }
    });
    page.on('response', async (res) => {
      const entry = recs.get(res.request());
      const req = res.request();
      const ct = (res.headers()['content-type'] || '').toLowerCase();
      const isScript = req.resourceType() === 'script' || /javascript|ecmascript/.test(ct);
      const isData = ['fetch', 'xhr'].includes(req.resourceType()) && /json|text|xml|x-www-form/.test(ct);
      let body = null, bytes = null;
      if ((isScript || isData) && res.status() < 400) {
        try { const buf = await res.body(); bytes = buf.length; if (bytes <= (isScript ? MAX_SCRIPT_BYTES : 2_000_000)) body = buf.toString('utf8'); } catch { /* body unavailable (redirect/aborted) */ }
      }
      if (entry) store.completeRequest(entry.rec, { status: res.status(), statusText: res.statusText(), headers: res.headers(), body: isData ? body : null, bodyBytes: bytes, durationMs: Date.now() - entry.start });
      if (isScript && body != null && res.status() < 400) this.indexScript(res.url(), body, ct, res.status(), entry?.rec.id);
      else if (isScript && body == null && bytes) this.index.skipped.push({ url: res.url(), reason: `script larger than ${MAX_SCRIPT_BYTES} bytes` });
    });
    page.on('requestfailed', (req) => { const e = recs.get(req); if (e) e.rec.failure = req.failure()?.errorText || 'failed'; });
    page.on('websocket', (ws) => {
      const rec = store.addWebSocket(ws.url());
      this.onEvent({ type: 'websocket', id: rec.id, url: rec.url });
      ws.on('framesent', (f) => store.addFrame(rec, 'sent', f.payload));
      ws.on('framereceived', (f) => store.addFrame(rec, 'received', f.payload));
      ws.on('close', () => { rec.closedAt = new Date().toISOString(); });
      ws.on('socketerror', (e) => { rec.error = truncate(String(e), 200); });
    });
    page.on('crash', () => this.onEvent({ type: 'warning', message: 'Page crashed' }));
    // CDP: initiator stacks (best effort)
    this.context.newCDPSession(page).then(async (cdp) => {
      this.cdp = cdp;
      await cdp.send('Network.enable');
      cdp.on('Network.requestWillBeSent', (e) => {
        const frames = e.initiator?.stack?.callFrames || [];
        const f = frames.find((x) => x.url) || null;
        const key = `${e.request.method} ${e.request.url}`;
        const arr = this.initiators.get(key) || [];
        arr.push({ type: e.initiator?.type, url: e.initiator?.url || f?.url || null, line: f ? f.lineNumber + 1 : e.initiator?.lineNumber != null ? e.initiator.lineNumber + 1 : null, column: f ? f.columnNumber : null, functionName: f?.functionName || null });
        this.initiators.set(key, arr);
      });
    }).catch(() => { /* CDP unavailable: initiators simply not reported */ });
  }

  indexScript(url, body, contentType, status, requestId) {
    if (this.known.has(url)) return;
    this.known.add(url);
    const res = this.index.addResource({ url, kind: 'script', content: body, contentType, status, requestId, sourceMapUrl: findMapRef(body, url) });
    if (!res) return;
    this.onEvent({ type: 'resource', id: res.id, url });
    if (res.sourceMapUrl && this.settings.inspectSourceMaps) this.pending.add(this.fetchMap(res).catch(() => { res.sourceMapStatus = 'fetch failed'; }));
  }

  async fetchMap(res) {
    if (res.sourceMapUrl.startsWith('data:')) {
      const m = res.sourceMapUrl.match(/^data:[^,]*;base64,(.*)$/);
      if (m) this.index.attachSourceMap(res.id, Buffer.from(m[1], 'base64').toString('utf8'));
      return;
    }
    await assertPublicUrl(res.sourceMapUrl);
    const r = await this.context.request.get(res.sourceMapUrl, { timeout: 15000, maxRedirects: 3 });
    if (!r.ok()) { res.sourceMapStatus = `unavailable (HTTP ${r.status()})`; return; }
    const buf = await r.body();
    if (buf.length > MAX_MAP_BYTES) { res.sourceMapStatus = 'skipped (too large)'; return; }
    this.index.attachSourceMap(res.id, buf.toString('utf8'));
  }

  /** Attach CDP initiator info to captured requests (heuristic match by method+URL in order). */
  resolveInitiators() {
    const counters = new Map();
    for (const r of this.store.requests.values()) {
      const raw = r.url;
      for (const [key, arr] of this.initiators) {
        if (!key.endsWith(' ' + raw) && !key.endsWith(' ' + raw.replace(/\/$/, ''))) continue;
        if (!key.startsWith(r.method + ' ')) continue;
        const i = counters.get(key) || 0;
        if (arr[i]) { r.initiator = { ...arr[i], url: arr[i].url, note: 'CDP initiator, matched to request by method+URL order' }; counters.set(key, i + 1); }
        break;
      }
    }
  }

  async navigate(rawUrl, { timeoutMs = 30000 } = {}) {
    if (this.disconnected) throw new ToolError('Browser disconnected', 'browser_disconnected');
    const u = await assertPublicUrl(rawUrl);
    const beforeReq = this.store.requests.size, beforeRes = this.index.resources.size;
    let status = 'ok', httpStatus = null, error = null;
    try {
      const resp = await this.page.goto(u.toString(), { waitUntil: 'load', timeout: timeoutMs });
      httpStatus = resp?.status() ?? null;
      await this.page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => { status = 'ok (network did not fully idle)'; });
    } catch (e) { status = 'failed'; error = truncate(String(e.message).split('\n')[0], 300); }
    await Promise.allSettled([...this.pending]); this.pending.clear();
    // inline scripts
    try {
      const inline = await this.page.evaluate(() => [...document.scripts].filter((s) => !s.src && s.textContent && s.textContent.length > 40 && (!s.type || /javascript|module/.test(s.type))).map((s) => s.textContent));
      const base = this.page.url();
      inline.forEach((code, i) => { const key = `inline:${base}#${i}`; if (!this.known.has(key)) { this.known.add(key); this.index.addResource({ url: base, name: `inline script #${i + 1} of ${base}`, kind: 'inline', content: code }); } });
    } catch { /* page may have navigated away */ }
    this.resolveInitiators();
    return {
      status, httpStatus, error, finalUrl: this.page.url(), title: await this.page.title().catch(() => ''),
      newRequests: this.store.requests.size - beforeReq, newScripts: this.index.resources.size - beforeRes,
      websockets: this.store.websockets.size
    };
  }

  async close() {
    try { await this.context?.close(); } catch {}
    try { await this.browser?.close(); } catch {}
  }
}

function findMapRef(body, scriptUrl) {
  const m = body.slice(-2000).match(/\/\/[#@]\s*sourceMappingURL=([^\s'"]+)/);
  if (!m) return null;
  try { return m[1].startsWith('data:') ? m[1] : new URL(m[1], scriptUrl).toString(); } catch { return null; }
}
