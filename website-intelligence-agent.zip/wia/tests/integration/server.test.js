import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../../src/server/app.js';
import { FakeEngine } from '../helpers.js';

const KEY = 'sk-or-v1-integrationkey1234567890';
function tmpDir() { return fs.mkdtempSync(path.join(os.tmpdir(), 'wia-srv-')); }

/** Fake OpenRouter: first call searches, second submits an answer. */
function fakeOpenRouter() {
  let n = 0; const log = [];
  return {
    log,
    fetchImpl: async (url, init) => {
      log.push({ url, auth: init.headers.Authorization });
      if (url.endsWith('/models')) return new Response(JSON.stringify({ data: [{ id: 'm/primary', supported_parameters: ['tools'] }] }), { status: 200 });
      if (url.endsWith('/auth/key')) return new Response('{}', { status: 200 });
      const msg = n++ === 0
        ? { role: 'assistant', content: null, tool_calls: [{ id: 'a', type: 'function', function: { name: 'search_files', arguments: '{"query":"buildRequestId"}' } }] }
        : { role: 'assistant', content: null, tool_calls: [{ id: 'b', type: 'function', function: { name: 'submit_answer', arguments: JSON.stringify({ answer: 'ids.js buildRequestId', findings: [{ claim: 'defined in ids.js', status: 'verified', confidence: 'high', evidence: [{ type: 'code', resourceId: 'f2', startLine: 1, endLine: 3 }] }] }) } }] };
      return new Response(JSON.stringify({ choices: [{ message: msg }] }), { status: 200 });
    }
  };
}
async function boot(env = {}, extra = {}) {
  const or = fakeOpenRouter();
  const app = createApp({ dataDir: tmpDir(), env, fetchImpl: or.fetchImpl, engineFactory: (o) => new FakeEngine(o), runtimeStatus: () => ({ ok: true, detail: 'fake' }), ...extra });
  const server = await new Promise((r) => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const j = async (p, o = {}) => { const r = await fetch(base + p, { ...o, headers: { 'Content-Type': 'application/json', ...(o.headers || {}) }, body: o.body ? JSON.stringify(o.body) : undefined }); return { status: r.status, body: await r.json().catch(() => null) }; };
  return { base, j, or, close: () => new Promise((r) => server.close(r)) };
}
const waitDone = async (j, convId) => { for (let i = 0; i < 100; i++) { const c = (await j(`/api/conversations/${convId}`)).body; if (c.messages.some((m) => m.role === 'assistant')) return c; await new Promise((r) => setTimeout(r, 50)); } throw new Error('timeout'); };

test('unconfigured app explains what is missing instead of failing silently', async () => {
  const s = await boot(); try {
    const st = (await s.j('/api/status')).body; assert.deepEqual(st.missingConfig, ['OpenRouter API key', 'Primary Reasoning Model']);
    const c = (await s.j('/api/conversations', { method: 'POST' })).body;
    const r = await s.j(`/api/conversations/${c.id}/investigate`, { method: 'POST', body: { question: 'where is the id built', targetUrl: 'https://93.184.216.34', authorized: true } });
    assert.equal(r.status, 400); assert.match(r.body.error, /Settings/); assert.equal(r.body.code, 'not_configured');
  } finally { await s.close(); }
});

test('key save/validate/clear: key never returned; settings validated', async () => {
  const s = await boot(); try {
    let r = await s.j('/api/settings/key', { method: 'PUT', body: { apiKey: KEY } });
    assert.ok(!JSON.stringify(r.body).includes('integrationkey')); assert.equal(r.body.key.configured, true);
    assert.ok(!JSON.stringify((await s.j('/api/settings')).body).includes('integrationkey'));
    const cur = (await s.j('/api/settings')).body; const next = { models: { ...cur.models, primary: 'm/primary' }, investigation: cur.investigation };
    assert.equal((await s.j('/api/settings', { method: 'PUT', body: next })).status, 200);
    assert.equal((await s.j('/api/settings', { method: 'PUT', body: { ...next, investigation: { ...next.investigation, maxSteps: 0 } } })).status, 400);
    const v = (await s.j('/api/settings/validate', { method: 'POST' })).body; assert.ok(v.key.ok); assert.equal(v.models.primary.status, 'ok');
    assert.equal((await s.j('/api/settings/key', { method: 'DELETE' })).body.key.configured, false);
  } finally { await s.close(); }
});

test('full investigation flow over HTTP persists a verified result; concurrent run rejected; SSE streams phases', async () => {
  const s = await boot({ OPENROUTER_API_KEY: KEY }); try {
    const cur = (await s.j('/api/settings')).body;
    await s.j('/api/settings', { method: 'PUT', body: { models: { ...cur.models, primary: 'm/primary' }, investigation: cur.investigation } });
    const c = (await s.j('/api/conversations', { method: 'POST' })).body;
    const bad = await s.j(`/api/conversations/${c.id}/investigate`, { method: 'POST', body: { question: 'where is the id built', targetUrl: 'https://93.184.216.34', authorized: false } });
    assert.equal(bad.status, 400);
    const ssrf = await s.j(`/api/conversations/${c.id}/investigate`, { method: 'POST', body: { question: 'where is the id built', targetUrl: 'http://169.254.169.254/latest', authorized: true } });
    assert.equal(ssrf.status, 400); assert.match(ssrf.body.error, /rejected|Blocked/i);
    const go = await s.j(`/api/conversations/${c.id}/investigate`, { method: 'POST', body: { question: 'where is the id built', targetUrl: 'https://93.184.216.34/', authorized: true } });
    assert.equal(go.status, 202);
    const sse = await (await fetch(`${s.base}/api/runs/${go.body.runId}/events`)).text();
    assert.match(sse, /"phase":"Planning"/); assert.match(sse, /"type":"tool_start"/); assert.match(sse, /"type":"done"/);
    const conv = await waitDone(s.j, c.id);
    const a = conv.messages.find((m) => m.role === 'assistant');
    assert.equal(a.status, 'completed'); assert.match(a.result.findings[0].evidence[0].snippet, /buildRequestId/);
    assert.ok(!JSON.stringify(conv).includes('integrationkey'));
    assert.ok(s.or.log.filter((l) => l.url.endsWith('/chat/completions')).every((l) => l.auth === `Bearer ${KEY}`));
    assert.equal((await s.j('/api/data', { method: 'DELETE' })).status, 400);
    assert.equal((await s.j('/api/data?confirm=yes', { method: 'DELETE' })).body.cleared, true);
    assert.equal((await s.j('/api/conversations')).body.length, 0);
  } finally { await s.close(); }
});

test('browser runtime unavailable -> clear 503', async () => {
  const s = await boot({ OPENROUTER_API_KEY: KEY }, { runtimeStatus: () => ({ ok: false, detail: 'Chromium is not installed' }) }); try {
    const cur = (await s.j('/api/settings')).body; await s.j('/api/settings', { method: 'PUT', body: { models: { ...cur.models, primary: 'm/primary' }, investigation: cur.investigation } });
    const c = (await s.j('/api/conversations', { method: 'POST' })).body;
    const r = await s.j(`/api/conversations/${c.id}/investigate`, { method: 'POST', body: { question: 'where is the id built', targetUrl: 'https://93.184.216.34/', authorized: true } });
    assert.equal(r.status, 503); assert.match(r.body.error, /Chromium/);
  } finally { await s.close(); }
});

test('APP_PASSWORD gates everything except /healthz', async () => {
  const s = await boot({ APP_PASSWORD: 'pw123' }); try {
    assert.equal((await fetch(s.base + '/api/settings')).status, 401); assert.equal((await fetch(s.base + '/')).status, 401);
    assert.equal((await fetch(s.base + '/healthz')).status, 200);
    const ok = await fetch(s.base + '/api/settings', { headers: { Authorization: 'Basic ' + Buffer.from('u:pw123').toString('base64') } }); assert.equal(ok.status, 200);
    const bad = await fetch(s.base + '/api/settings', { headers: { Authorization: 'Basic ' + Buffer.from('u:nope').toString('base64') } }); assert.equal(bad.status, 401);
  } finally { await s.close(); }
});

test('conversation rename/delete', async () => {
  const s = await boot(); try {
    const c = (await s.j('/api/conversations', { method: 'POST' })).body;
    assert.equal((await s.j(`/api/conversations/${c.id}`, { method: 'PATCH', body: { title: 'Renamed' } })).body.title, 'Renamed');
    assert.equal((await s.j(`/api/conversations/${c.id}`, { method: 'DELETE' })).body.deleted, true);
    assert.equal((await s.j(`/api/conversations/${c.id}`)).status, 404);
  } finally { await s.close(); }
});
