import test from 'node:test';
import assert from 'node:assert/strict';
import { runInvestigation } from '../../src/agent/loop.js';
import { DEFAULT_SETTINGS } from '../../src/shared/schemas.js';
import { FakeEngine, freshState, scriptedGateway, call, FIXTURE } from '../helpers.js';

const URL0 = 'https://fixture.example/';
const settings = (o = {}) => ({ ...DEFAULT_SETTINGS, investigation: { ...DEFAULT_SETTINGS.investigation, ...o } });
function setup(script, inv) {
  const { store, index } = freshState();
  const engine = new FakeEngine({ store, codeIndex: index });
  const gateway = scriptedGateway(script);
  const events = [];
  const run = (signal) => runInvestigation({ question: 'Which function builds the requestId in the WebSocket message?', targetUrl: URL0, settings: settings(inv), gateway, engine, store, index, signal, emit: (e) => events.push(e) });
  return { store, index, gateway, events, run };
}
const lastToolResult = (m) => JSON.parse([...m].reverse().find((x) => x.role === 'tool').content);

test('multi-file investigation: rejects irrelevant candidate, follows reference into 2nd file, verified answer with verbatim snippets', async () => {
  let idsId, mainId;
  const t = setup([
    call('search_files', { query: 'nonexistentThing' }),                       // irrelevant candidate -> nothing
    call('search_files', { query: 'requestId' }),
    (m) => { const r = lastToolResult(m).output; mainId = r.matches[0].resourceId; return call('trace_references', { name: 'buildRequestId' }); },
    (m) => { const r = lastToolResult(m).output; idsId = r.definitions[0].resourceId; assert.notEqual(idsId, mainId); return call('get_file_excerpt', { resource_id: idsId, start_line: 1, end_line: 3 }); },
    () => call('list_websockets', {}),
    () => call('submit_answer', {
      answer: 'buildRequestId(prefix) in ids.js creates the requestId; main.js calls it when sending the subscribe frame.',
      findings: [{ claim: 'requestId is created by buildRequestId in ids.js', status: 'verified', confidence: 'high', confidenceReason: 'Definition read directly; caller in main.js builds the message', relationship: 'inferred', relationshipNote: 'Frame field name and call site match; no runtime call-stack proof for WebSockets',
        evidence: [{ type: 'code', resourceId: idsId, startLine: 1, endLine: 3 }, { type: 'code', resourceId: mainId, startLine: 4 }, { type: 'ws', connectionId: 'w1', frameId: 'w1:f1' }] }],
      limitations: ['Server-side validation of the ID is not visible from client code.']
    })
  ]);
  const out = await t.run();
  assert.equal(out.status, 'completed'); assert.equal(out.stopReason, 'answered');
  const f = out.result.findings[0];
  assert.equal(f.status, 'verified'); assert.ok(f.evidence.every((e) => e.resolved));
  assert.equal(f.evidence[0].snippet.split('\n')[0], FIXTURE.ids.split('\n')[0]);          // verbatim from captured artifact
  assert.match(f.evidence[1].snippet, /buildRequestId\('sub'\)/);
  assert.ok(!f.evidence[2].frame.payload.includes('supersecretvalue123'));                  // redacted in stored frame
  assert.ok(t.events.some((e) => e.phase === 'Tracing References') && t.events.some((e) => e.phase === 'Completed'));
  assert.ok(out.actions.some((a) => a.tool === 'search_files' && /0 matches/.test(a.summary)));  // irrelevant candidate recorded, loop continued
});

test('fabricated evidence is not trusted: unresolved refs downgrade a "verified" finding', async () => {
  const t = setup([call('submit_answer', { answer: 'It is in nowhere.js', findings: [{ claim: 'Defined in nowhere.js line 5', status: 'verified', confidence: 'high', evidence: [{ type: 'code', resourceId: 'f99', startLine: 5 }, { type: 'request', requestId: 'r999' }] }] })]);
  const out = await t.run();
  const f = out.result.findings[0];
  assert.equal(f.status, 'hypothesis'); assert.notEqual(f.confidence, 'high'); assert.ok(f.evidence.every((e) => !e.resolved)); assert.match(f.verifierNote, /Downgraded/);
});

test('model-supplied snippets are ignored; only captured text is shown', async () => {
  const t = setup([call('search_files', { query: 'buildRequestId' }), call('submit_answer', { answer: 'x', findings: [{ claim: 'c', status: 'verified', confidence: 'medium', evidence: [{ type: 'code', resourceId: 'f2', startLine: 1, snippet: 'FAKE CODE' }] }] })]);
  const out = await t.run();
  assert.ok(!JSON.stringify(out.result).includes('FAKE CODE'));
});

test('invalid tool args and unknown ids produce errors the agent can recover from', async () => {
  const t = setup([call('get_file_excerpt', { resource_id: 'zzz', start_line: 1 }), call('get_request', {}), call('submit_answer', { answer: 'Could not confirm.', findings: [{ claim: 'unknown', status: 'unresolved', confidence: 'low' }] })]);
  const out = await t.run();
  assert.equal(out.status, 'completed'); assert.deepEqual(out.actions.filter((a) => !a.ok).map((a) => a.tool), ['get_file_excerpt', 'get_request']);
});

test('model failure mid-run keeps all captured evidence and reports a partial result', async () => {
  const t = setup([call('search_files', { query: 'requestId' }), Object.assign(new Error('All configured models failed. a/p: HTTP 503'), { code: 'all_failed' })]);
  const out = await t.run();
  assert.equal(out.status, 'partial'); assert.equal(out.stopReason, 'model_failure'); assert.match(out.error, /models failed/);
  assert.ok(out.evidenceSummary.requests >= 3 && out.evidenceSummary.resources === 2 && out.evidenceSummary.frames === 2);
  assert.equal(t.store.requests.size >= 3, true);
});

test('step budget: forces a final best-effort answer', async () => {
  const t = setup([call('list_resources', {}), call('list_resources', {}), call('submit_answer', { answer: 'Partial: only listed resources.', findings: [{ claim: 'Not traced', status: 'unresolved', confidence: 'low' }], unresolved: ['caller not traced'] })], { maxSteps: 2 });
  const out = await t.run();
  assert.equal(out.stopReason, 'step_budget'); assert.equal(out.status, 'partial'); assert.ok(out.result);
});

test('cancellation stops the loop without a result', async () => {
  const ac = new AbortController();
  const t = setup([() => { ac.abort(); return call('list_resources', {}); }, call('list_resources', {})]);
  const out = await t.run(ac.signal);
  assert.equal(out.status, 'cancelled'); assert.equal(t.gateway.calls, 1);
});

test('time budget is enforced', async () => {
  const t = setup([call('list_resources', {})], { timeBudgetSec: 15 });
  const realNow = Date.now; let skew = 0; Date.now = () => realNow() + skew;
  try {
    const p = t.run(); skew = 16_000; const out = await p;
    assert.ok(['time_budget', 'partial'].includes(out.stopReason) || out.status !== 'completed');
  } finally { Date.now = realNow; }
});

test('tool output sent to the model is bounded and secrets are redacted', async () => {
  const t = setup([call('list_requests', { keyword: 'quote' }), call('get_request', { request_id: 'r4' }), call('submit_answer', { answer: 'ok', findings: [] })]);
  await t.run();
  const raw = JSON.stringify(t.gateway.seen);
  const req = t.store.getRequest('r4');
  assert.equal(req.requestHeaders.authorization, '[REDACTED]'); assert.ok(!req.url.includes('zzz')); assert.ok(!(req.body || '').includes('abcdef123456'));
  assert.ok(raw.length > 0);
});

test('navigate tool refuses hosts outside the authorized target', async () => {
  const t = setup([call('navigate', { url: 'https://evil.example/x' }), call('submit_answer', { answer: 'ok', findings: [] })]);
  const out = await t.run();
  assert.equal(out.actions.find((a) => a.tool === 'navigate' && a.args.url.includes('evil')).ok, false);
});
