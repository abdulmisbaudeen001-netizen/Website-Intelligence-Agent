import { buildRequestId } from './ids.js';
function openSocket() {
  const ws = new WebSocket(`ws://${location.host}/ws`);
  ws.onopen = () => { const msg = { type: 'subscribe', requestId: buildRequestId('sub'), token: 'supersecretvalue123' }; ws.send(JSON.stringify(msg)); };
  ws.onmessage = (e) => { window.__last = e.data; };
}
openSocket();
fetch('/api/quote?symbol=ABC', { headers: { Authorization: 'Bearer abc.def.ghi-secret-token' } });
