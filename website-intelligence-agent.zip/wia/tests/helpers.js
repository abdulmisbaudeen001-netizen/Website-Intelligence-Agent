import fs from 'node:fs';
import { EvidenceStore } from '../src/evidence/store.js';
import { CodeIndex } from '../src/code/index.js';

const read = (f) => fs.readFileSync(new URL('./fixtures/site/' + f, import.meta.url), 'utf8');
export const FIXTURE = { main: read('main.js'), ids: read('ids.js') };

/** Stands in for the Playwright engine: populates store/index exactly like the real capture would for the fixture site. */
export class FakeEngine {
  constructor({ store, codeIndex, onEvent }) { Object.assign(this, { store, index: codeIndex, onEvent }); }
  async start() {}
  async close() { this.closed = true; }
  async navigate(url) {
    const before = this.store.requests.size;
    const doc = this.store.addRequest({ method: 'GET', url, resourceType: 'document', headers: {} });
    this.store.completeRequest(doc, { status: 200, headers: { 'content-type': 'text/html' }, durationMs: 5 });
    for (const [n, c] of [['main.js', FIXTURE.main], ['ids.js', FIXTURE.ids]]) {
      const r = this.store.addRequest({ method: 'GET', url: new URL('/' + n, url).toString(), resourceType: 'script', headers: {} });
      this.store.completeRequest(r, { status: 200, headers: { 'content-type': 'application/javascript' }, durationMs: 3 });
      this.index.addResource({ url: r.url, content: c, requestId: r.id });
    }
    const q = this.store.addRequest({ method: 'GET', url: new URL('/api/quote?symbol=ABC&token=zzz', url).toString(), resourceType: 'fetch', headers: { Authorization: 'Bearer abc.def.ghi-secret-token' } });
    this.store.completeRequest(q, { status: 200, headers: { 'content-type': 'application/json' }, body: '{"price":1,"session":"abcdef123456"}', durationMs: 9 });
    const ws = this.store.addWebSocket(new URL('/ws', url).toString().replace('http', 'ws'));
    this.store.addFrame(ws, 'sent', '{"type":"subscribe","requestId":"sub-abc-123","token":"supersecretvalue123"}');
    this.store.addFrame(ws, 'received', '{"ok":true}');
    return { status: 'ok', httpStatus: 200, error: null, finalUrl: url, title: 'Fixture shop', newRequests: this.store.requests.size - before, newScripts: 2, websockets: 1 };
  }
}

export function freshState(opts = {}) { return { store: new EvidenceStore(opts), index: new CodeIndex(opts) }; }

/** Scripted LLM: each entry is a message ({tool_calls|content}) or a function(messages)->message or an Error to throw. */
export function scriptedGateway(script) {
  let i = 0;
  return {
    usage: [], calls: 0, seen: [],
    async chat({ messages, signal }) {
      this.calls++; this.seen.push(messages.length);
      if (signal?.aborted) throw Object.assign(new Error('Cancelled'), { code: 'aborted' });
      const s = script[Math.min(i++, script.length - 1)];
      if (s instanceof Error) throw s;
      const message = typeof s === 'function' ? s(messages) : s;
      return { message, meta: { model: 'mock/primary', slot: 'primary', fallbackUsed: false } };
    }
  };
}
let n = 0;
export const call = (name, args) => ({ role: 'assistant', content: null, tool_calls: [{ id: 'tc' + ++n, type: 'function', function: { name, arguments: JSON.stringify(args) } }] });
