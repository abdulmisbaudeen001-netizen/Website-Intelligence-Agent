import test from 'node:test';
import assert from 'node:assert/strict';
import { assertPublicUrl, isPrivateIp } from '../../src/browser/urlguard.js';

test('private ranges detected', () => {
  for (const ip of ['127.0.0.1', '10.1.2.3', '172.16.0.1', '192.168.1.1', '169.254.169.254', '100.64.0.1', '::1', 'fd00::1', 'fe80::1', '::ffff:127.0.0.1']) assert.ok(isPrivateIp(ip), ip);
  for (const ip of ['8.8.8.8', '93.184.216.34', '2606:4700:4700::1111']) assert.ok(!isPrivateIp(ip), ip);
});
test('blocks bad schemes and local hosts', async () => {
  for (const u of ['file:///etc/passwd', 'ftp://x.com', 'javascript:alert(1)']) await assert.rejects(assertPublicUrl(u, { allowPrivate: false }), /scheme/i);
  for (const u of ['http://localhost:3000', 'http://127.0.0.1/', 'http://169.254.169.254/latest/meta-data', 'http://[::1]/', 'http://foo.internal/']) await assert.rejects(assertPublicUrl(u, { allowPrivate: false }), /Blocked/);
});
test('allowPrivate bypass works only when explicit', async () => { await assertPublicUrl('http://127.0.0.1:9', { allowPrivate: true }); });
