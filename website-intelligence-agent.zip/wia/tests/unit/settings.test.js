import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { SettingsStore } from '../../src/config/settings.js';

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'wia-'));
test('without APP_SECRET the key stays in memory only', () => {
  const dir = tmp(); const s = new SettingsStore({ dir, env: {} }); s.setKey('sk-or-v1-memonly12345');
  assert.equal(s.key(), 'sk-or-v1-memonly12345'); assert.ok(!fs.existsSync(path.join(dir, 'openrouter.key.enc')));
  assert.ok(!JSON.stringify(s.publicView()).includes('memonly')); assert.match(s.keySource(), /memory/);
});
test('with APP_SECRET the key is encrypted at rest and reloads', () => {
  const dir = tmp(); const env = { APP_SECRET: 'a-long-secret' }; const s = new SettingsStore({ dir, env }); s.setKey('sk-or-v1-persisted12345');
  const raw = fs.readFileSync(path.join(dir, 'openrouter.key.enc'), 'utf8'); assert.ok(!raw.includes('persisted'));
  assert.equal(new SettingsStore({ dir, env }).key(), 'sk-or-v1-persisted12345');
  assert.equal(new SettingsStore({ dir, env: { APP_SECRET: 'wrong' } }).key(), null);
  s.clearKey(); assert.ok(!fs.existsSync(path.join(dir, 'openrouter.key.enc')));
});
test('env key takes precedence; settings validated and persisted', () => {
  const dir = tmp(); const s = new SettingsStore({ dir, env: { OPENROUTER_API_KEY: 'sk-or-env-key-123456' } });
  assert.equal(s.key(), 'sk-or-env-key-123456');
  const next = structuredClone(s.get()); next.models.primary = 'x/y';
  s.update(next); assert.equal(new SettingsStore({ dir, env: {} }).get().models.primary, 'x/y');
  next.investigation.maxSteps = 9999; assert.throws(() => s.update(next));
  next.investigation.maxSteps = 10; next.models.primary = 'bad id with spaces'; assert.throws(() => s.update(next));
});
