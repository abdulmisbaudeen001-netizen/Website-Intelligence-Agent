import test from 'node:test';
import assert from 'node:assert/strict';
import { ModelGateway } from '../../src/gateway/openrouter.js';

const KEY = 'sk-or-v1-supersecretkey1234567890';
const ok = (content = 'hi', extra = {}) => new Response(JSON.stringify({ choices: [{ message: { role: 'assistant', content, ...extra } }], usage: { total_tokens: 5 } }), { status: 200 });
function mk(handler, models = { primary: 'a/p', code: '', fallback: 'b/f' }, key = KEY) {
  const calls = [];
  const fetchImpl = async (url, init) => { const body = init.body ? JSON.parse(init.body) : null; calls.push({ url, model: body?.model }); return handler(url, body, calls); };
  const events = [];
  return { gw: new ModelGateway({ getKey: () => key, getModels: () => models, fetchImpl, backoffMs: 1, onEvent: (e) => events.push(e) }), calls, events };
}
const models = (list) => new Response(JSON.stringify({ data: list }), { status: 200 });

test('no key -> actionable error, no network call', async () => {
  const { gw, calls } = mk(() => ok(), undefined, null);
  await assert.rejects(gw.chat({ messages: [] }), /not configured/); assert.equal(calls.length, 0);
});
test('no model configured -> actionable error', async () => {
  const { gw } = mk(() => ok(), { primary: '', code: '', fallback: '' });
  await assert.rejects(gw.chat({ messages: [] }), /No model configured/);
});
test('retryable failure retried on same model then succeeds', async () => {
  let n = 0; const { gw, calls } = mk(() => (n++ === 0 ? new Response('rate', { status: 429 }) : ok('done')));
  const r = await gw.chat({ messages: [] }); assert.equal(r.message.content, 'done'); assert.equal(r.meta.fallbackUsed, false); assert.deepEqual(calls.map((c) => c.model), ['a/p', 'a/p']);
});
test('primary exhausted -> fallback used and reported', async () => {
  const { gw, calls, events } = mk((u, b) => (b.model === 'a/p' ? new Response('boom', { status: 503 }) : ok('from fallback')));
  const r = await gw.chat({ messages: [] });
  assert.equal(r.message.content, 'from fallback'); assert.ok(r.meta.fallbackUsed); assert.equal(events[0].type, 'fallback');
  assert.equal(calls.filter((c) => c.model === 'a/p').length, 2); // bounded attempts
});
test('non-retryable (401) does not retry same model; all failed -> bounded error, key scrubbed', async () => {
  const { gw, calls } = mk(() => new Response(`bad key ${KEY}`, { status: 401 }));
  await assert.rejects(gw.chat({ messages: [] }), (e) => { assert.equal(e.code, 'all_failed'); assert.ok(!e.message.includes(KEY)); assert.ok(!e.message.includes('supersecretkey')); return true; });
  assert.equal(calls.length, 2); // one per configured model, no retries
});
test('never calls an unconfigured model; code slot defaults to primary', async () => {
  const { gw, calls } = mk(() => ok(), { primary: 'a/p', code: '', fallback: '' });
  await gw.chat({ task: 'code', messages: [] }); assert.deepEqual(calls.map((c) => c.model), ['a/p']);
});
test('malformed JSON from provider is retryable', async () => {
  let n = 0; const { gw } = mk(() => (n++ === 0 ? new Response('<html>', { status: 200 }) : ok('fine')));
  assert.equal((await gw.chat({ messages: [] })).message.content, 'fine');
});
test('model without tool support is skipped for tool calls', async () => {
  const { gw, calls } = mk((u, b) => (u.endsWith('/models') ? models([{ id: 'a/p', supported_parameters: ['temperature'] }, { id: 'b/f', supported_parameters: ['tools'] }]) : ok('x')));
  const r = await gw.chat({ messages: [], tools: [{ type: 'function', function: { name: 'x', parameters: {} } }] });
  assert.equal(r.meta.model, 'b/f'); assert.ok(!calls.some((c) => c.model === 'a/p'));
});
test('abort signal -> cancelled, no fallback attempts', async () => {
  const ac = new AbortController(); const { gw, calls } = mk(() => ok());
  ac.abort(); await assert.rejects(gw.chat({ messages: [], signal: ac.signal }), /Cancelled/); assert.equal(calls.length, 0);
});
test('validate: key ok, invalid model flagged, unconfigured reported', async () => {
  const { gw } = mk((u) => (u.endsWith('/auth/key') ? new Response('{}', { status: 200 }) : models([{ id: 'a/p', supported_parameters: ['tools'], context_length: 1000 }])), { primary: 'a/p', code: 'nope/none', fallback: '' });
  const v = await gw.validate();
  assert.ok(v.key.ok); assert.equal(v.models.primary.status, 'ok'); assert.equal(v.models.code.status, 'invalid'); assert.equal(v.models.fallback.status, 'unconfigured');
});
test('validate: rejected key reported without leaking it', async () => {
  const { gw } = mk(() => new Response('no', { status: 401 })); const v = await gw.validate();
  assert.equal(v.key.ok, false); assert.ok(!JSON.stringify(v).includes(KEY));
});
