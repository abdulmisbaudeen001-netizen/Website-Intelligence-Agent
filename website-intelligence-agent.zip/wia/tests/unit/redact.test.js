import test from 'node:test';
import assert from 'node:assert/strict';
import { redactHeaders, redactText, redactUrl, redactDeep } from '../../src/evidence/redact.js';

test('headers: secrets redacted, others kept', () => {
  const h = redactHeaders({ Authorization: 'Bearer abc', Cookie: 'sid=1', 'Content-Type': 'application/json' });
  assert.equal(h.authorization, '[REDACTED]'); assert.equal(h.cookie, '[REDACTED]'); assert.equal(h['content-type'], 'application/json');
});
test('text: bearer, jwt, key=value, sk- keys', () => {
  const t = redactText('Authorization: Bearer abcdefghijk1234 {"token":"hunter2xyz","ok":1} eyJhbGciOiJIUzI1.eyJzdWIiOiIxMjM0.SflKxwRJSMeKKF2QT4 sk-or-v1-abcdefghijklmnopqrstuv');
  for (const s of ['abcdefghijk1234', 'hunter2xyz', 'SflKxwRJSMeKKF2QT4', 'abcdefghijklmnopqrstuv']) assert.ok(!t.includes(s), `${s} leaked`);
  assert.ok(t.includes('"ok":1'));
});
test('url: sensitive query params and credentials redacted', () => {
  const u = redactUrl('https://user:pw@x.com/a?api_key=SECRET&q=1');
  assert.ok(!u.includes('SECRET') && !u.includes('pw@')); assert.ok(u.includes('q=1'));
});
test('deep: sensitive keys redacted', () => { assert.equal(redactDeep({ password: 'x', a: { sessionId: 'y', b: 1 } }).a.sessionId, '[REDACTED]'); });
