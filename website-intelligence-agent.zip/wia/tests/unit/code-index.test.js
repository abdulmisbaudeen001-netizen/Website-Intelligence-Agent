import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { CodeIndex } from '../../src/code/index.js';

const read = (f) => fs.readFileSync(new URL('../fixtures/site/' + f, import.meta.url), 'utf8');

test('indexes readable files, finds symbol, exact line/column', () => {
  const ix = new CodeIndex();
  const ids = ix.addResource({ url: 'https://t/ids.js', content: read('ids.js') });
  assert.equal(ids.view, 'original');
  const r = ix.search('buildRequestId');
  assert.equal(r.matches[0].line, 1); assert.equal(r.matches[0].symbol, 'buildRequestId');
  assert.match(ix.excerpt(ids.id, 1, 3).text, /Date\.now\(\)/);
});
test('follows a reference across files', () => {
  const ix = new CodeIndex();
  ix.addResource({ url: 'https://t/main.js', content: read('main.js') });
  ix.addResource({ url: 'https://t/ids.js', content: read('ids.js') });
  const t = ix.traceReferences('buildRequestId');
  assert.equal(t.definitions.length, 1); assert.ok(t.callers.some((c) => c.callerSymbol === 'onopen' || c.callerSymbol === 'openSocket' || c.callerSymbol));
  assert.notEqual(t.definitions[0].resourceId, t.callers[0].resourceId);
  assert.ok(ix.traceReferences('./ids.js').importsMatching.length === 1);
});
test('minified code is beautified, original size preserved, flags set', () => {
  const ix = new CodeIndex();
  const min = 'var a=function(){' + 'x=1;'.repeat(600) + '};function sendQuote(s){return fetch("/api/quote?symbol="+s)}';
  const r = ix.addResource({ url: 'https://t/m.js', content: min });
  assert.ok(r.minified && r.view === 'beautified'); assert.equal(r.originalBytes, min.length);
  assert.equal(ix.search('/api/quote').matches[0].symbol, 'sendQuote');
});
test('source map sources become exact-provenance resources', () => {
  const ix = new CodeIndex();
  const b = ix.addResource({ url: 'https://t/b.js', content: 'function a(){}', sourceMapUrl: 'https://t/b.js.map' });
  const map = { version: 3, file: 'b.js', sources: ['webpack://app/src/orig.ts', 'webpack://app/node_modules/x.js'], sourcesContent: ['export function realName(){return 1}', 'lib'], names: [], mappings: 'AAAA' };
  const added = ix.attachSourceMap(b.id, map);
  assert.equal(added.length, 1); assert.equal(added[0].name, 'src/orig.ts');
  assert.equal(ix.search('realName', { kind: 'sourcemap-source' }).matches.length, 1);
  assert.match(b.sourceMapStatus, /loaded/);
});
test('parse failure is recorded, not thrown; invalid inputs rejected', () => {
  const ix = new CodeIndex();
  const r = ix.addResource({ url: 'https://t/bad.js', content: 'function ((( {' });
  assert.ok(r.parseError); assert.throws(() => ix.get('nope'), /Unknown resource/);
  assert.throws(() => ix.search('(', { regex: true }), /Invalid regex/);
});
test('maxCodeResources bound enforced', () => {
  const ix = new CodeIndex({ maxResources: 2 });
  for (let i = 0; i < 4; i++) ix.addResource({ url: `https://t/${i}.js`, content: 'var a=1;' });
  assert.equal(ix.resources.size, 2); assert.equal(ix.skipped.length, 2);
});
