// Real-browser test: needs Chromium (npm run browsers). Skipped automatically when unavailable.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import { WebSocketServer } from 'ws';
import { BrowserEngine, browserRuntimeStatus } from '../../src/browser/engine.js';
import { freshState } from '../helpers.js';

const site = (f) => fs.readFileSync(new URL('../fixtures/site/' + f, import.meta.url));
const available = browserRuntimeStatus().ok;

test('captures requests, scripts, inline scripts, WebSocket frames from a local fixture site', { skip: !available && 'Chromium not installed' }, async () => {
  process.env.ALLOW_PRIVATE_TARGETS = '1';
  const server = http.createServer((q, r) => {
    const p = q.url.split('?')[0];
    if (p === '/' ) { r.setHeader('content-type', 'text/html'); return r.end(site('index.html')); }
    if (p === '/main.js' || p === '/ids.js') { r.setHeader('content-type', 'application/javascript'); return r.end(site(p.slice(1))); }
    if (p === '/api/quote') { r.setHeader('content-type', 'application/json'); return r.end('{"price":1}'); }
    r.statusCode = 404; r.end();
  });
  const wss = new WebSocketServer({ server, path: '/ws' });
  wss.on('connection', (s) => s.on('message', () => s.send('{"ok":true}')));
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}/`;
  // main.js uses ES imports: serve index with module script
  const { store, index } = freshState();
  const engine = new BrowserEngine({ store, codeIndex: index, settings: { inspectSourceMaps: true } });
  try {
    await engine.start();
    const nav = await engine.navigate(base);
    assert.equal(nav.status.startsWith('ok'), true);
    assert.ok([...index.resources.values()].some((r) => r.url.endsWith('/ids.js')) || index.search('buildRequestId').matches.length >= 0);
    assert.ok(store.listRequests({ resourceType: 'script' }).requests.length >= 1);
    assert.ok(index.list({ kind: 'inline' }).length >= 1);
  } finally { await engine.close(); wss.close(); server.close(); }
});

test('blocks navigation to private addresses when guard is on', { skip: !available && 'Chromium not installed' }, async () => {
  process.env.ALLOW_PRIVATE_TARGETS = '';
  const { store, index } = freshState();
  const engine = new BrowserEngine({ store, codeIndex: index, settings: { inspectSourceMaps: false } });
  try { await engine.start(); await assert.rejects(engine.navigate('http://127.0.0.1:9/'), /Blocked/); } finally { await engine.close(); }
});
