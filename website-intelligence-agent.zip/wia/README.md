# Website Intelligence Agent

Ask a technical question about a website you are authorized to test. An LLM agent drives an isolated Playwright browser, captures requests / scripts / WebSocket frames, indexes and parses the JavaScript (source maps when exposed), follows references across files, and returns findings with **verbatim, verifiable evidence**. Investigation is read-only.

## Quick start
```bash
npm ci
npm run browsers            # installs Chromium for Playwright
cp .env.example .env        # optional; export the vars you need
npm start                   # http://localhost:3000
```
Open **Settings**: save your OpenRouter key, set model IDs (Primary must support tool calling), click *Validate*. Then enter a target URL, tick the authorization box, ask a question.

## Tests
```bash
npm test         # 43 unit + integration tests (no browser or network needed)
npm run test:e2e # real-browser tests; auto-skipped when Chromium is missing
```

## Deploy (Render)
See `docs/setup.md`. Short version: push to GitHub → Render *New → Blueprint* → pick the repo → set `APP_PASSWORD` (and optionally `OPENROUTER_API_KEY`).

## Layout
`src/browser` Playwright capture · `src/code` JS indexing/parsing/search · `src/tools` typed agent tools · `src/gateway` OpenRouter routing/fallback · `src/agent` loop, prompts, verifier · `src/evidence` store + redaction · `src/server` API/SSE/auth · `public` UI · `tests` · `docs`.

Docs: `docs/architecture.md`, `docs/security.md`, `docs/setup.md`, `docs/troubleshooting.md`.
