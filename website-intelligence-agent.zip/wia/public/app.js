const $ = (s) => document.querySelector(s);
function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v; else if (k.startsWith('on')) el.addEventListener(k.slice(2), v); else el.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) el.append(k.nodeType ? k : document.createTextNode(String(k)));
  return el;
}
async function api(path, opts = {}) {
  const r = await fetch(path, { ...opts, headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) }, body: opts.body ? JSON.stringify(opts.body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(j.error || `Request failed (${r.status})`), { code: j.code });
  return j;
}

const PHASES = ['Planning', 'Inspecting Network', 'Searching Scripts', 'Tracing References', 'Verifying Evidence', 'Completed'];
const STOP_TEXT = { answered: 'Answered with verified evidence', step_budget: 'Stopped: step budget reached', time_budget: 'Stopped: time budget reached', cancelled: 'Cancelled', model_failure: 'Stopped: model unavailable', no_progress: 'Stopped: agent made no further progress', navigation_failed: 'Stopped: target could not be loaded', invalid_answers: 'Stopped: agent could not produce a valid answer' };
const state = { convs: [], id: null, run: null, es: null, settings: null };

// ---------- conversations
async function loadConvs() { state.convs = await api('/api/conversations'); renderConvs(); }
function renderConvs() {
  const ul = $('#convList'); ul.replaceChildren();
  for (const c of state.convs) {
    ul.append(h('li', { class: c.id === state.id ? 'active' : '' },
      h('button', { class: 'name', title: c.title, onclick: () => select(c.id) }, c.title),
      h('button', { class: 'mini', 'aria-label': 'Rename', title: 'Rename', onclick: () => rename(c) }, '✎'),
      h('button', { class: 'mini', 'aria-label': 'Delete', title: 'Delete', onclick: () => del(c) }, '🗑')));
  }
}
async function newConv() { const c = await api('/api/conversations', { method: 'POST' }); await loadConvs(); await select(c.id); }
async function rename(c) { const t = prompt('Rename investigation', c.title); if (t && t.trim()) { await api(`/api/conversations/${c.id}`, { method: 'PATCH', body: { title: t.trim() } }); await loadConvs(); if (c.id === state.id) $('#title').textContent = t.trim(); } }
async function del(c) { if (!confirm(`Delete "${c.title}"? This cannot be undone.`)) return; await api(`/api/conversations/${c.id}`, { method: 'DELETE' }); if (c.id === state.id) state.id = null; await loadConvs(); if (!state.id) state.convs[0] ? select(state.convs[0].id) : newConv(); }
async function select(id) {
  state.id = id; showView('chat'); $('#sidebar').classList.remove('open');
  const c = await api(`/api/conversations/${id}`);
  $('#title').textContent = c.title; renderConvs();
  const box = $('#messages'); box.replaceChildren();
  const last = [...c.messages].reverse().find((m) => m.targetUrl); if (last) $('#target').value = last.targetUrl;
  if (!c.messages.length) box.append(h('div', { class: 'empty' }, h('h2', {}, 'Ask a technical question about a website'), h('p', {}, 'Enter an authorized site and a question such as “Which script sends the order request, and where is its payload built?” The agent captures network activity and code, then answers with cited evidence.')));
  for (const m of c.messages) box.append(m.role === 'user' ? userMsg(m) : resultMsg(m));
  box.scrollTop = box.scrollHeight;
  if (state.run && state.run.convId === id) box.append(state.run.el);
}
function userMsg(m) { return h('div', { class: 'msg user' }, h('div', { class: 'bubble' }, m.content), h('small', {}, m.targetUrl || '')); }

// ---------- result rendering (all text via textContent: website content is untrusted)
function codeBlock(text, lang = 'javascript') {
  const code = h('code', { class: `language-${lang}` }, text);
  try { if (window.hljs) window.hljs.highlightElement(code); } catch {}
  const btn = h('button', { class: 'btn sm copy', onclick: async () => { try { await navigator.clipboard.writeText(text); btn.textContent = 'Copied'; setTimeout(() => (btn.textContent = 'Copy'), 1200); } catch { btn.textContent = 'Copy failed'; } } }, 'Copy');
  return h('div', { class: 'codewrap' }, btn, h('pre', {}, code));
}
function evidenceEl(e) {
  if (!e.resolved) return h('div', { class: 'meta' }, `⚠ Unresolvable evidence reference (${e.type}: ${e.resourceId || e.requestId || e.connectionId}). It was not found in captured data.`);
  if (e.type === 'code') return h('details', { class: 'ev' }, h('summary', {}, `Code · ${e.name} · lines ${e.startLine}–${e.endLine} (${e.view})`),
    h('div', { class: 'body' }, h('div', { class: 'meta' }, `Resource ${e.resourceId} · ${e.url}`), h('div', { class: 'meta' }, `${e.locationNote} Source map: ${e.sourceMap}.`), codeBlock(e.snippet)));
  if (e.type === 'request') return h('details', { class: 'ev' }, h('summary', {}, `Request ${e.requestId} · ${e.method} ${e.url} → ${e.status ?? 'n/a'}`),
    h('div', { class: 'body' }, h('div', { class: 'meta' }, `${e.timestamp} · ${e.resourceType}`),
      e.initiator ? h('div', { class: 'meta' }, `Initiator (CDP, heuristic match): ${e.initiator.url || 'n/a'}${e.initiator.line ? `:${e.initiator.line}` : ''}${e.initiator.functionName ? ` in ${e.initiator.functionName}` : ''}`) : null,
      e.postData ? h('div', {}, h('div', { class: 'meta' }, 'Request body (redacted, truncated)'), codeBlock(e.postData, 'json')) : null,
      e.body ? h('div', {}, h('div', { class: 'meta' }, 'Response body (redacted, truncated)'), codeBlock(e.body, 'json')) : null));
  return h('details', { class: 'ev' }, h('summary', {}, `WebSocket ${e.connectionId}${e.frameId ? ' · frame ' + e.frameId : ''} · ${e.url}`),
    h('div', { class: 'body' }, e.frame ? h('div', {}, h('div', { class: 'meta' }, `${e.frame.direction} · ${e.frame.timestamp}`), codeBlock(e.frame.payload, 'json')) : h('div', { class: 'meta' }, 'Connection-level evidence.')));
}
function resultMsg(m) {
  const card = h('div', { class: 'card' });
  const banner = { completed: 'ok', partial: 'warn', cancelled: 'warn', error: 'bad' }[m.status] || 'warn';
  card.append(h('div', { class: 'meta' }, h('span', { class: `pill ${banner}` }, m.status === 'completed' ? 'Completed' : m.status === 'partial' ? 'Partial result' : m.status === 'cancelled' ? 'Cancelled' : 'Error'), ' ', STOP_TEXT[m.stopReason] || ''));
  if (m.error) card.append(h('p', { class: 'hint bad' }, m.error));
  const r = m.result;
  if (r) {
    card.append(h('h3', {}, 'Answer'), h('div', { class: 'answer' }, r.answer));
    if (r.findings?.length) card.append(h('h3', { style: 'margin-top:14px' }, 'Findings'));
    for (const f of r.findings || []) card.append(h('div', { class: 'finding' },
      h('div', {}, h('span', { class: `badge ${f.status}` }, f.status), h('span', { class: 'badge conf' }, `${f.confidence} confidence`), f.claim),
      f.confidenceReason ? h('div', { class: 'meta' }, `Why: ${f.confidenceReason}`) : null,
      f.relationship !== 'none' ? h('div', { class: 'meta' }, `Code ↔ network relationship: ${f.relationship}${f.relationshipNote ? ' — ' + f.relationshipNote : ''}`) : null,
      f.verifierNote ? h('div', { class: 'meta' }, `⚠ ${f.verifierNote}`) : null,
      (f.evidence || []).map(evidenceEl)));
    const list = (title, items) => items?.length ? h('div', {}, h('h3', { style: 'margin-top:14px' }, title), h('ul', { class: 'plain' }, items.map((x) => h('li', {}, x)))) : null;
    card.append(list('Limitations', r.limitations), list('Unresolved', r.unresolved), list('Next steps', r.nextSteps), list('Verifier notes', r.verifierNotes));
  } else if (m.topCandidates?.length) {
    card.append(h('p', {}, 'No verified answer was produced. Highest-ranked candidates from the evidence collected (heuristic ranking, not proof):'),
      h('ul', { class: 'plain' }, m.topCandidates.map((c) => h('li', {}, `${c.resourceId} ${c.name} — ${c.signals.join(', ')}`))));
  }
  const s = m.evidenceSummary;
  if (s) card.append(h('p', { class: 'meta' }, `Evidence captured: ${s.requests} requests, ${s.websockets} WebSockets (${s.frames} frames), ${s.resources} code resources, ${s.steps} agent steps, ${Math.round((s.elapsedMs || 0) / 1000)}s. Evidence is preserved even when the model fails.`));
  const fb = (m.models || []).filter((x) => x.fallbackUsed);
  if (fb.length) card.append(h('p', { class: 'meta' }, `Fallback model used for ${fb.length} call(s): ${[...new Set(fb.map((x) => x.model))].join(', ')}`));
  if (m.actions?.length) card.append(h('details', { class: 'ev' }, h('summary', {}, `Investigation actions (${m.actions.length})`), h('div', { class: 'body' }, h('ul', { class: 'plain' }, m.actions.map((a) => h('li', {}, `${a.tool} ${a.ok ? '✓' : '✗'} — ${a.summary}`))))));
  return h('div', { class: 'msg' }, card);
}

// ---------- live progress
function progressCard() {
  const phases = h('div', { class: 'phases' }, PHASES.map((p) => h('span', { class: 'phase', 'data-p': p }, p)));
  const log = h('div', { class: 'log', role: 'log' });
  const el = h('div', { class: 'msg' }, h('div', { class: 'card progress' }, h('strong', {}, 'Investigating…'), phases, log));
  return { el, phases, log };
}
function setPhase(run, p) {
  const idx = PHASES.indexOf(p);
  run.phases.querySelectorAll('.phase').forEach((n, i) => { n.classList.toggle('on', i === idx); n.classList.toggle('done', idx >= 0 && i < idx && p === 'Completed'); });
}
function logLine(run, text, bad) { run.log.append(h('div', { class: bad ? 'bad' : '' }, text)); run.log.scrollTop = run.log.scrollHeight; }

async function start(ev) {
  ev.preventDefault();
  if (!state.id) await newConv();
  const body = { question: $('#question').value, targetUrl: $('#target').value, authorized: $('#authorized').checked };
  if (!body.authorized) return notice('Confirm that you own or are authorized to test this website.');
  notice('');
  let runId;
  try { ({ runId } = await api(`/api/conversations/${state.id}/investigate`, { method: 'POST', body })); }
  catch (e) { return notice(e.message, e.code === 'not_configured'); }
  $('#question').value = '';
  const convId = state.id;
  const pc = progressCard();
  state.run = { id: runId, convId, ...pc };
  const box = $('#messages'); box.querySelector('.empty')?.remove();
  box.append(userMsg({ content: body.question, targetUrl: body.targetUrl }), pc.el); box.scrollTop = box.scrollHeight;
  setRunning(true);
  const es = new EventSource(`/api/runs/${runId}/events`); state.es = es;
  es.onmessage = (m) => {
    const e = JSON.parse(m.data);
    if (e.type === 'phase') { setPhase(state.run, e.phase); logLine(state.run, `${e.phase}${e.detail ? ' — ' + e.detail : ''}`); }
    else if (e.type === 'tool_start') logLine(state.run, `→ ${e.tool} ${JSON.stringify(e.args).slice(0, 140)}`);
    else if (e.type === 'tool_end') logLine(state.run, `${e.ok ? '✓' : '✗'} ${e.tool}: ${e.summary}`, !e.ok);
    else if (e.type === 'resource') logLine(state.run, `  script indexed: ${e.url}`);
    else if (e.type === 'websocket') logLine(state.run, `  websocket: ${e.url}`);
    else if (e.type === 'fallback') logLine(state.run, `⚠ fallback model in use: ${e.model}`);
    else if (e.type === 'error') logLine(state.run, `error: ${e.message}`, true);
    else if (e.type === 'done') { es.close(); finish(convId); }
  };
  es.onerror = () => { if (es.readyState === EventSource.CLOSED) finish(convId); };
}
async function finish(convId) {
  if (!state.run) return; state.run = null; state.es = null; setRunning(false);
  await loadConvs(); if (state.id === convId) await select(convId); refreshStatus();
}
function setRunning(on) { $('#btnStart').disabled = on; $('#btnStop').hidden = !on; $('#btnStart').textContent = on ? 'Running…' : 'Start Investigation'; }
function notice(msg, cfg) {
  const n = $('#notice'); n.hidden = !msg; n.replaceChildren();
  if (msg) { n.append(msg); if (cfg) n.append(' ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); showView('settings'); } }, 'Open Settings')); }
}

// ---------- status & settings
async function refreshStatus() {
  try {
    const s = await api('/api/status'); const p = $('#statusPills'); p.replaceChildren();
    p.append(h('span', { class: `pill ${s.browser.ok ? 'ok' : 'bad'}`, title: s.browser.detail }, s.browser.ok ? 'Browser ready' : 'Browser unavailable'));
    p.append(h('span', { class: `pill ${s.missingConfig.length ? 'warn' : 'ok'}`, title: s.missingConfig.join(', ') }, s.missingConfig.length ? `Setup: ${s.missingConfig.join(', ')}` : 'Models configured'));
    if (s.activeRunId) p.append(h('span', { class: 'pill warn' }, 'Investigation running'));
    if (s.missingConfig.length && !state.run) notice(`Setup needed: ${s.missingConfig.join(' and ')}. `, true);
    else if (!state.run) notice('');
    const rt = $('#runtime'); if (rt) { rt.replaceChildren(h('div', {}, `Browser runtime: ${s.browser.ok ? 'ready' : 'unavailable'} — ${s.browser.detail}`), h('div', {}, `Current investigation: ${s.activeRunId ? 'running' : 'idle'}`), h('div', {}, `Password protection: ${s.security.passwordProtected ? 'on' : 'OFF (set APP_PASSWORD before exposing this app)'}`)); }
  } catch {}
}
function tag(id, status) { const t = $(id); t.textContent = status === 'ok' ? 'valid' : status === 'invalid' ? 'invalid' : status === 'unconfigured' ? 'unconfigured' : status === 'set' ? 'configured' : status; t.className = 'tag ' + (status === 'ok' || status === 'set' ? 'ok' : status === 'invalid' ? 'bad' : ''); }
async function loadSettings() {
  const s = state.settings = await api('/api/settings');
  $('#mPrimary').value = s.models.primary; $('#mCode').value = s.models.code; $('#mFallback').value = s.models.fallback;
  for (const [slot, id] of [['Primary', s.models.primary], ['Code', s.models.code], ['Fallback', s.models.fallback]]) tag('#s' + slot, id ? 'set' : 'unconfigured');
  const i = s.investigation;
  $('#iMaxRequests').value = i.maxRequests; $('#iMaxResources').value = i.maxCodeResources; $('#iMaxSteps').value = i.maxSteps; $('#iTime').value = i.timeBudgetSec; $('#iPayload').value = i.payloadLimit; $('#iMaps').checked = i.inspectSourceMaps; $('#iRetain').checked = i.retainArtifacts;
  $('#keyStatus').textContent = s.key.configured ? `API key configured (${s.key.masked}) — source: ${s.key.source}.` : 'No API key configured.';
  $('#keyStatus').className = 'hint ' + (s.key.configured ? 'ok' : 'warn');
  if (s.key.configured && s.key.source.includes('memory')) $('#keyStatus').append(' Set APP_SECRET on the server to persist it encrypted, or provide OPENROUTER_API_KEY as an environment variable.');
  modelWarn(); refreshStatus();
}
function modelWarn() {
  const p = $('#mPrimary').value.trim(), f = $('#mFallback').value.trim(), w = $('#modelWarn');
  w.hidden = !(p && f && p === f); w.textContent = 'Fallback model equals the primary model: it provides no redundancy if that model is down or rate-limited.';
}
async function saveSettings() {
  const num = (id) => Number($(id).value);
  try {
    await api('/api/settings', { method: 'PUT', body: { models: { primary: $('#mPrimary').value.trim(), code: $('#mCode').value.trim(), fallback: $('#mFallback').value.trim() }, investigation: { maxRequests: num('#iMaxRequests'), maxCodeResources: num('#iMaxResources'), maxSteps: num('#iMaxSteps'), timeBudgetSec: num('#iTime'), payloadLimit: num('#iPayload'), inspectSourceMaps: $('#iMaps').checked, retainArtifacts: $('#iRetain').checked } } });
    $('#saveMsg').textContent = 'Saved.'; $('#saveMsg').className = 'hint ok'; await loadSettings();
  } catch (e) { $('#saveMsg').textContent = e.message; $('#saveMsg').className = 'hint bad'; }
}
async function validate() {
  const v = $('#validation'); v.textContent = 'Validating…'; v.className = 'hint';
  try {
    const r = await api('/api/settings/validate', { method: 'POST' });
    v.replaceChildren(h('div', { class: r.key.ok ? 'ok' : 'bad' }, `Key: ${r.key.message}`), ...Object.entries(r.models).map(([k, m]) => h('div', { class: m.status === 'ok' ? 'ok' : m.status === 'invalid' ? 'bad' : '' }, `${k}: ${m.message}`)));
    for (const [slot, m] of Object.entries(r.models)) tag('#s' + slot[0].toUpperCase() + slot.slice(1), m.status);
    refreshStatus();
  } catch (e) { v.textContent = e.message; v.className = 'hint bad'; }
}

function showView(v) { $('#chatView').hidden = v !== 'chat'; $('#settingsView').hidden = v !== 'settings'; if (v === 'settings') loadSettings(); }

// ---------- wire up
$('#btnNew').onclick = newConv;
$('#btnMenu').onclick = () => $('#sidebar').classList.toggle('open');
$('#btnSettings').onclick = () => showView('settings');
$('#btnBack').onclick = () => showView('chat');
$('#composer').addEventListener('submit', start);
$('#btnStop').onclick = async () => { if (state.run) { try { await api(`/api/runs/${state.run.id}/cancel`, { method: 'POST' }); logLine(state.run, 'Cancelling…'); } catch (e) { notice(e.message); } } };
$('#btnSaveKey').onclick = async () => { try { await api('/api/settings/key', { method: 'PUT', body: { apiKey: $('#apiKey').value } }); $('#apiKey').value = ''; await loadSettings(); } catch (e) { $('#keyStatus').textContent = e.message; $('#keyStatus').className = 'hint bad'; } };
$('#btnClearKey').onclick = async () => { await api('/api/settings/key', { method: 'DELETE' }); await loadSettings(); };
$('#btnValidate').onclick = validate;
$('#btnSaveSettings').onclick = saveSettings;
$('#mPrimary').oninput = $('#mFallback').oninput = modelWarn;
$('#btnClearData').onclick = async () => { if (!confirm('Delete ALL conversations and stored evidence? This cannot be undone.')) return; await api('/api/data?confirm=yes', { method: 'DELETE' }); state.id = null; await loadConvs(); await newConv(); showView('chat'); };

(async () => {
  await loadConvs();
  state.convs[0] ? await select(state.convs[0].id) : await newConv();
  refreshStatus(); setInterval(refreshStatus, 15000);
})();
