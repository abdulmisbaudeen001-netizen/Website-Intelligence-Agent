# Security
- Whole app behind HTTP Basic auth (`APP_PASSWORD`); the server refuses to start in production without it. `/healthz` is the only open route.
- OpenRouter key: backend only; never returned by any API, never logged, scrubbed from gateway errors. Persisted only if `APP_SECRET` is set (AES-256-GCM). `OPENROUTER_API_KEY` env var takes precedence.
- SSRF: only http(s); hostnames resolved and rejected if private/loopback/link-local/metadata. Every browser sub-request is checked via Playwright route interception; `navigate` is limited to the authorized host. **Known gap:** WebSocket handshakes are not route-intercepted; DNS-rebinding between check and connect is not fully excluded.
- Isolated throwaway browser context; service workers blocked; downloads disabled; no persistent profile.
- Redaction (headers, URLs, bodies, frames, JWT/Bearer/API-key patterns) runs on write, before display or LLM exposure. Pattern-based: novel secret formats can slip through.
- Prompt injection: tool output is declared untrusted in the system prompt, answers are schema-validated, evidence is verified server-side, and the agent has no state-changing tools. Prompt-level defenses are not a guarantee.
- Limits: request/script/payload caps, step/time budgets, tool timeouts, 20 investigations/hour/IP, one run at a time.
- Authorization checkbox is required per investigation; use only on sites you own or may test.
