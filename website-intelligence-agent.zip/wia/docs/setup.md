# Setup
## Local
`npm ci && npm run browsers && npm start`. For local tests against `localhost` targets set `ALLOW_PRIVATE_TARGETS=1` (never on a public deployment).

## GitHub
```bash
git remote add origin https://github.com/<you>/website-intelligence-agent.git
git push -u origin main
```
## Render
1. Render dashboard → New → Blueprint → select the repo (reads `render.yaml`; Docker build installs Chromium).
2. Set `APP_PASSWORD`. Optionally `OPENROUTER_API_KEY`. `APP_SECRET` is generated.
3. Open the service URL, log in (any username, your password), configure Settings.
Notes: `render.yaml` requests the `standard` plan and a 1 GB disk at `/data`; plan names/limits should be checked against Render's current pricing. Without a disk, conversations are lost on redeploy.

## OpenRouter
Create a key at openrouter.ai, paste it in Settings → Save → Validate. Choose models that support tool calling (Validate reports this when OpenRouter advertises it).
