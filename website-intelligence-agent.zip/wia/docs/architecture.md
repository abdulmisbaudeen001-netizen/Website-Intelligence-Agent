# Architecture
Stack: Node 22, Express, vanilla-JS UI, zod for validation at module boundaries, Playwright (single browser driver) + best-effort CDP session for request initiators, acorn/acorn-walk (parsing), js-beautify, source-map-js. JSDoc-typed plain ESM (no build step). Trade-off: less compile-time typing than TypeScript, simpler deployment.

Flow: UI → `POST /api/conversations/:id/investigate` → run (SSE `/api/runs/:id/events`) → `BrowserEngine` fills `EvidenceStore` + `CodeIndex` → `runInvestigation` loops: model (via `ModelGateway`) picks tools (`src/tools`) → results (bounded, redacted) back to model → `submit_answer` → `verifyAnswer` → stored in the conversation.

Key decisions
- **Verifier, not trust:** the model cites evidence by id + line range. The server resolves each reference against captured data and attaches the verbatim snippet itself. Unresolvable references downgrade `verified` findings to `hypothesis`.
- **Evidence outlives model failures:** store/index are outside the loop; model errors yield a partial result with the evidence summary and heuristic candidate ranking.
- **Model slots:** Primary (planning/tools) → Fallback; Code model only used by `analyze_code` (defaults to Primary). ≤2 attempts per model for retryable errors; never calls an unconfigured model; tool-less models are skipped for tool calls.
- **Locations:** exact for original files and source-map sources; for minified files without maps, line numbers refer to the *beautified* view (original column offsets are not preserved) and are labeled so.
- **Call graph:** static, name-based (heuristic; labeled as such).
- **Initiators:** CDP `requestWillBeSent` initiators are matched to requests by method+URL order (heuristic; labeled).
