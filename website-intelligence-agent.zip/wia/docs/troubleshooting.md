# Troubleshooting
- **"Browser unavailable"**: run `npm run browsers` (local) or check the Docker build log (Render).
- **Chromium crashes / OOM on Render**: use a plan with ≥2 GB RAM; lower *Max code resources* and *Max captured requests*.
- **"tool calling NOT advertised"**: pick a different model; the agent needs tool calls.
- **Target rejected**: private/local addresses are blocked by design.
- **Script not indexed**: larger than 3 MB, over the resource cap, or loaded from a worker; see `list_resources` → skipped.
- **Minified, no source map**: line numbers refer to the beautified view; findings are labeled accordingly.
- **Key lost after restart**: set `APP_SECRET` (encrypted persistence) or use `OPENROUTER_API_KEY`.
